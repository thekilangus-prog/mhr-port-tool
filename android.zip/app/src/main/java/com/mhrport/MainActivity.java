package com.mhrport;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_PICK = 1, REQ_SAVE = 2;
    private static final String NO_WEAPON = "Belum ada senjata dipilih (tanpa ganti ID)";
    private TextView logView, selectedView;
    private Button pickBtn, saveBtn;
    private EditText nameEdit, idEdit;
    private CheckBox prefabCheck;
    private File outFile;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        outFile = new File(getCacheDir(), "out.pak");
        cleanupFiles();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        TextView info = new TextView(this);
        info.setText("Port mod MHR PC (STM) ke Switch (NSW) jadi file .pak.\n"
                + "1. (Opsional) Pilih senjata tujuan dari daftar untuk layered weapon (ID terisi otomatis).\n"
                + "2. Pilih file mod .zip atau .rar (berisi folder natives).\n"
                + "3. Tunggu proses selesai.\n4. Simpan file .pak.");
        root.addView(info);

        nameEdit = new EditText(this);
        nameEdit.setSingleLine(true);
        nameEdit.setInputType(InputType.TYPE_CLASS_TEXT);
        nameEdit.setText("re_chunk_000.pak.patch_016.pak");
        root.addView(nameEdit);

        // ID model tujuan diisi lewat daftar senjata, tidak perlu diketik.
        idEdit = new EditText(this);
        idEdit.setSingleLine(true);
        idEdit.setInputType(InputType.TYPE_NULL);
        idEdit.setFocusable(false);
        idEdit.setCursorVisible(false);
        idEdit.setFilters(new InputFilter[] { new InputFilter.LengthFilter(3) });
        idEdit.setHint("Ketuk untuk memilih senjata tujuan (kosong = tanpa ganti ID)");
        idEdit.setOnClickListener(v -> showWeaponPicker());
        root.addView(idEdit);

        selectedView = new TextView(this);
        selectedView.setText(NO_WEAPON);
        root.addView(selectedView);

        LinearLayout weaponRow = new LinearLayout(this);
        weaponRow.setOrientation(LinearLayout.HORIZONTAL);
        Button listBtn = new Button(this);
        listBtn.setText("Pilih senjata tujuan");
        listBtn.setOnClickListener(v -> showWeaponPicker());
        weaponRow.addView(listBtn, new LinearLayout.LayoutParams(0, -2, 1f));
        Button clearBtn = new Button(this);
        clearBtn.setText("Hapus pilihan");
        clearBtn.setOnClickListener(v -> {
            idEdit.setText("");
            selectedView.setText(NO_WEAPON);
        });
        weaponRow.addView(clearBtn, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(weaponRow);

        prefabCheck = new CheckBox(this);
        prefabCheck.setText("Buang file prefab PC (disarankan; cegah senjata tidak muncul)");
        prefabCheck.setChecked(true);
        root.addView(prefabCheck);

        pickBtn = new Button(this);
        pickBtn.setText("Pilih mod (ZIP/RAR)");
        pickBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_PICK);
        });
        root.addView(pickBtn);

        saveBtn = new Button(this);
        saveBtn.setText("Simpan .pak");
        saveBtn.setEnabled(false);
        saveBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/octet-stream");
            i.putExtra(Intent.EXTRA_TITLE, nameEdit.getText().toString().trim());
            startActivityForResult(i, REQ_SAVE);
        });
        root.addView(saveBtn);

        logView = new TextView(this);
        logView.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(logView);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView credit = new TextView(this);
        credit.setText("Credit by Silver KA");
        credit.setGravity(android.view.Gravity.CENTER);
        credit.setTextSize(13);
        credit.setPadding(0, p / 2, 0, 0);
        root.addView(credit, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (req == REQ_PICK) process(uri);
        else if (req == REQ_SAVE) save(uri);
    }

    private void process(Uri uri) {
        pickBtn.setEnabled(false);
        saveBtn.setEnabled(false);
        outFile.delete();
        logView.setText("Memproses... (bisa beberapa menit untuk tekstur besar)");
        final String dstId = idEdit.getText().toString().trim();
        final boolean dropPrefab = prefabCheck.isChecked();
        new Thread(() -> {
            String result;
            try {
                File in = new File(getCacheDir(), "in.bin");
                copy(getContentResolver().openInputStream(uri), new FileOutputStream(in));
                PyObject r = Python.getInstance().getModule("bridge")
                        .callAttr("run", in.getAbsolutePath(), outFile.getAbsolutePath(), dstId, "", dropPrefab);
                result = r.toString();
            } catch (Throwable t) {
                result = "GAGAL\n" + t;
            }
            new File(getCacheDir(), "in.bin").delete();
            final String text = result;
            runOnUiThread(() -> {
                logView.setText(text);
                pickBtn.setEnabled(true);
                saveBtn.setEnabled(text.startsWith("OK"));
            });
        }).start();
    }

    private void save(Uri uri) {
        try {
            copy(new FileInputStream(outFile), getContentResolver().openOutputStream(uri));
            outFile.delete();
            saveBtn.setEnabled(false);
            Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Gagal menyimpan: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private void showWeaponPicker() {
        final List<String> types = new ArrayList<>();
        try {
            for (PyObject o : Python.getInstance().getModule("bridge").callAttr("weapon_types").asList())
                types.add(o.toString());
        } catch (Throwable t) {
            Toast.makeText(this, "Gagal memuat daftar: " + t, Toast.LENGTH_LONG).show();
            return;
        }
        final List<String> all = new ArrayList<>();
        final List<String> shown = new ArrayList<>();
        final ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, shown);
        float d = getResources().getDisplayMetrics().density;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        final Spinner typeSp = new Spinner(this);
        typeSp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, types));
        box.addView(typeSp);
        final EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Cari nama senjata atau nomor ID");
        box.addView(search);
        ListView lv = new ListView(this);
        lv.setAdapter(adapter);
        box.addView(lv, new LinearLayout.LayoutParams(-1, (int) (420 * d)));

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Pilih senjata tujuan (ID hanya cocok dalam tipe yang sama)")
                .setView(box)
                .setNegativeButton("Tutup", null)
                .create();

        final Runnable refilter = () -> {
            String q = search.getText().toString().trim().toLowerCase();
            shown.clear();
            for (String row : all) if (row.toLowerCase().contains(q)) shown.add(row);
            adapter.notifyDataSetChanged();
        };
        typeSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                all.clear();
                try {
                    for (PyObject o : Python.getInstance().getModule("bridge")
                            .callAttr("weapon_list", types.get(pos)).asList())
                        all.add(o.toString());
                } catch (Throwable t) {
                    Toast.makeText(MainActivity.this, "Gagal memuat daftar: " + t, Toast.LENGTH_LONG).show();
                }
                refilter.run();
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { refilter.run(); }
        });
        lv.setOnItemClickListener((parent, view, pos, id) -> {
            String row = shown.get(pos);
            idEdit.setText(row.substring(0, 3));
            String label = row.split("\\s+\\|\\s+ID:")[0].trim();
            selectedView.setText(types.get(typeSp.getSelectedItemPosition()) + ": " + label);
            dlg.dismiss();
        });
        dlg.show();
    }

    private void cleanupFiles() {
        new File(getCacheDir(), "in.bin").delete();
        outFile.delete();
        try { Python.getInstance().getModule("bridge").callAttr("cleanup"); } catch (Throwable ignored) { }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (isFinishing()) {
            new File(getCacheDir(), "in.bin").delete();
            outFile.delete();
        }
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        try (InputStream i = in; OutputStream o = out) {
            byte[] buf = new byte[65536]; int n;
            while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
        }
    }
}
