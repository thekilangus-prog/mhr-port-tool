package com.mhrport;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.widget.*;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.*;

public class MainActivity extends Activity {
    private static final int REQ_PICK = 1, REQ_SAVE = 2;
    private TextView logView;
    private Button pickBtn, saveBtn;
    private EditText nameEdit, idEdit;
    private File outFile;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        outFile = new File(getCacheDir(), "out.pak");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        TextView info = new TextView(this);
        info.setText("Port mod MHR PC (STM) ke Switch (NSW) jadi file .pak.\n"
                + "1. (Opsional) Isi ID model tujuan untuk layered weapon, mis. 105 = Lan105.\n"
                + "2. Pilih file mod .zip atau .rar (berisi folder natives).\n"
                + "3. Tunggu proses selesai.\n4. Simpan file .pak.");
        root.addView(info);

        nameEdit = new EditText(this);
        nameEdit.setSingleLine(true);
        nameEdit.setInputType(InputType.TYPE_CLASS_TEXT);
        nameEdit.setText("re_chunk_000.pak.patch_016.pak");
        root.addView(nameEdit);

        idEdit = new EditText(this);
        idEdit.setSingleLine(true);
        idEdit.setInputType(InputType.TYPE_CLASS_NUMBER);
        idEdit.setFilters(new InputFilter[] { new InputFilter.LengthFilter(3) });
        idEdit.setHint("ID model tujuan, mis. 105 (kosong = tanpa ganti ID)");
        root.addView(idEdit);

        pickBtn = new Button(this);
        pickBtn.setText("Pilih mod (ZIP/RAR)");
        pickBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_PICK);
        });
        root.addView(pickBtn);

        saveBtn = new Button(this);
        saveBtn.setText("Simpan .pak");
        saveBtn.setEnabled(false);
        saveBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/octet-stream");
            i.putExtra(Intent.EXTRA_TITLE, nameEdit.getText().toString().trim());
            startActivityForResult(i, REQ_SAVE);
        });
        root.addView(saveBtn);

        logView = new TextView(this);
        logView.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(logView);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (req == REQ_PICK) process(uri);
        else if (req == REQ_SAVE) save(uri);
    }

    private void process(Uri uri) {
        pickBtn.setEnabled(false);
        saveBtn.setEnabled(false);
        logView.setText("Memproses... (bisa beberapa menit untuk tekstur besar)");
        final String dstId = idEdit.getText().toString().trim();
        new Thread(() -> {
            String result;
            try {
                File in = new File(getCacheDir(), "in.bin");
                copy(getContentResolver().openInputStream(uri), new FileOutputStream(in));
                PyObject r = Python.getInstance().getModule("bridge")
                        .callAttr("run", in.getAbsolutePath(), outFile.getAbsolutePath(), dstId, "");
                result = r.toString();
            } catch (Throwable t) {
                result = "GAGAL\n" + t;
            }
            final String text = result;
            runOnUiThread(() -> {
                logView.setText(text);
                pickBtn.setEnabled(true);
                saveBtn.setEnabled(text.startsWith("OK"));
            });
        }).start();
    }

    private void save(Uri uri) {
        try {
            copy(new FileInputStream(outFile), getContentResolver().openOutputStream(uri));
            Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Gagal menyimpan: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        try (InputStream i = in; OutputStream o = out) {
            byte[] buf = new byte[65536]; int n;
            while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
        }
    }
}
