"""
Pengekstrak RAR5 murni Python (tanpa dependensi) untuk MHR Port Tool.

Mendukung: file biasa (store) dan terkompresi method 1-5 (LZ + Huffman + filter
DELTA/E8/E8E9/ARM), arsip solid, nama UTF-8, cek CRC32.
Tidak mendukung: terenkripsi, multi-volume, RAR versi lama (4), kompresi versi 1 (RAR7).
"""
import os, struct, zlib

SIG5 = b'Rar!\x1a\x07\x01\x00'


class RarError(Exception):
    pass


# ----------------------------------------------------------------- utils ----
def _vint(b, p):
    r = 0; s = 0
    while True:
        if p >= len(b): raise RarError("header RAR terpotong")
        c = b[p]; p += 1
        r |= (c & 0x7F) << s; s += 7
        if not c & 0x80: return r, p


def _build_table(lens):
    """Tabel lookup Huffman kanonis 15-bit: entri = (simbol << 4) | panjang."""
    count = [0] * 16
    for l in lens:
        if l: count[l] += 1
    nxt = [0] * 17; code = 0
    for bits in range(1, 16):
        code = (code + count[bits - 1]) << 1 if bits > 1 else 0
        nxt[bits] = code
    tbl = [0] * 32768
    for sym, l in enumerate(lens):
        if not l: continue
        c = nxt[l]; nxt[l] += 1
        a = c << (15 - l); b = (c + 1) << (15 - l)
        if b > 32768: raise RarError("tabel Huffman tidak valid")
        tbl[a:b] = [(sym << 4) | l] * (b - a)
    return tbl


NC, DC, LDC, RC = 306, 64, 16, 44
BC = 20


class Unpacker:
    def __init__(self):
        self.hist = bytearray()
        self.reset()

    def reset(self):
        self.old = [0, 0, 0, 0]
        self.last_len = 0
        self.tabs = None

    # ---- satu file ----
    def unpack(self, data, usize, solid):
        if not solid:
            self.hist = bytearray(); self.reset()
        out = self.hist
        base = len(out)
        data = bytes(data) + b'\0' * 32
        ndata = len(data) - 32
        pos_byte = 0                      # posisi byte awal blok berikutnya
        filters = []
        old = self.old; last_len = self.last_len
        tabs = self.tabs

        while True:
            # --- header blok (rata byte) ---
            if pos_byte + 3 > ndata: raise RarError("data terkompresi terpotong")
            flags = data[pos_byte]; chk = data[pos_byte + 1]
            nbytes = ((flags >> 3) & 3) + 1
            if nbytes == 4: raise RarError("header blok tidak valid")
            bsize = int.from_bytes(data[pos_byte + 2:pos_byte + 2 + nbytes], 'little')
            x = 0x5A ^ flags
            for i in range(nbytes): x ^= (bsize >> (8 * i)) & 0xFF
            if x != chk: raise RarError("checksum header blok salah")
            bitsize = (flags & 7) + 1
            last_block = bool(flags & 0x40); table_present = bool(flags & 0x80)
            bstart = pos_byte + 2 + nbytes
            end_bit = (bstart + bsize - 1) * 8 + bitsize

            ip = bstart; buf = 0; cnt = 0

            def refill():
                nonlocal ip, buf, cnt
                buf = ((buf & ((1 << cnt) - 1)) << 64) | int.from_bytes(data[ip:ip + 8], 'big')
                ip += 8; cnt += 64

            if table_present:
                refill(); refill()
                bl = [0] * BC; i = 0
                while i < BC:
                    if cnt < 16: refill()
                    n = (buf >> (cnt - 4)) & 15; cnt -= 4
                    if n == 15:
                        z = (buf >> (cnt - 4)) & 15; cnt -= 4
                        if z == 0: bl[i] = 15; i += 1
                        else:
                            z += 2
                            while z > 0 and i < BC: bl[i] = 0; i += 1; z -= 1
                    else:
                        bl[i] = n; i += 1
                bd = _build_table(bl)
                total = NC + DC + LDC + RC
                lens = [0] * total; i = 0
                while i < total:
                    if cnt < 40: refill()
                    e = bd[(buf >> (cnt - 15)) & 0x7FFF]
                    ln = e & 15
                    if ln == 0: raise RarError("simbol tabel tidak valid")
                    cnt -= ln; num = e >> 4
                    if num < 16:
                        lens[i] = num; i += 1
                    elif num < 18:
                        if num == 16: n = ((buf >> (cnt - 3)) & 7) + 3; cnt -= 3
                        else: n = ((buf >> (cnt - 7)) & 127) + 11; cnt -= 7
                        if i == 0: raise RarError("tabel panjang tidak valid")
                        v = lens[i - 1]
                        while n > 0 and i < total: lens[i] = v; i += 1; n -= 1
                    else:
                        if num == 18: n = ((buf >> (cnt - 3)) & 7) + 3; cnt -= 3
                        else: n = ((buf >> (cnt - 7)) & 127) + 11; cnt -= 7
                        while n > 0 and i < total: lens[i] = 0; i += 1; n -= 1
                tabs = (_build_table(lens[:NC]),
                        _build_table(lens[NC:NC + DC]),
                        _build_table(lens[NC + DC:NC + DC + LDC]),
                        _build_table(lens[NC + DC + LDC:]))
            if tabs is None: raise RarError("blok tanpa tabel Huffman")
            LD, DD, LDD, RD = tabs

            # --- decode simbol ---
            target = base + usize
            while True:
                if cnt < 96: refill()
                if (ip << 3) - cnt >= end_bit: break
                e = LD[(buf >> (cnt - 15)) & 0x7FFF]
                ln = e & 15
                if ln == 0: raise RarError("kode Huffman tidak valid")
                cnt -= ln; sym = e >> 4
                if sym < 256:
                    out.append(sym); continue
                if sym == 256:                                   # filter
                    vals = []
                    for _ in range(2):
                        k = ((buf >> (cnt - 2)) & 3) + 1; cnt -= 2
                        v = 0
                        for j in range(k):
                            v += ((buf >> (cnt - 8)) & 255) << (8 * j); cnt -= 8
                        vals.append(v)
                    ftype = (buf >> (cnt - 3)) & 7; cnt -= 3
                    ch = 0
                    if ftype == 0:
                        ch = ((buf >> (cnt - 5)) & 31) + 1; cnt -= 5
                    filters.append((len(out) + vals[0], vals[1], ftype, ch))
                    continue
                if sym == 257:
                    if last_len:
                        _copy(out, last_len, old[0])
                    continue
                if sym < 262:
                    idx = sym - 258
                    dist = old[idx]
                    for k in range(idx, 0, -1): old[k] = old[k - 1]
                    old[0] = dist
                    e = RD[(buf >> (cnt - 15)) & 0x7FFF]; ln = e & 15
                    if ln == 0: raise RarError("kode panjang tidak valid")
                    cnt -= ln; slot = e >> 4
                    length, cnt = _slot_len(slot, buf, cnt)
                    last_len = length
                    _copy(out, length, dist)
                    continue
                length, cnt = _slot_len(sym - 262, buf, cnt)
                e = DD[(buf >> (cnt - 15)) & 0x7FFF]; ln = e & 15
                if ln == 0: raise RarError("kode jarak tidak valid")
                cnt -= ln; ds = e >> 4
                if ds < 4:
                    dist = 1 + ds; dbits = 0
                else:
                    dbits = ds // 2 - 1
                    dist = 1 + ((2 | (ds & 1)) << dbits)
                if dbits > 0:
                    if dbits >= 4:
                        if dbits > 4:
                            dist += ((buf >> (cnt - (dbits - 4))) & ((1 << (dbits - 4)) - 1)) << 4
                            cnt -= dbits - 4
                        e = LDD[(buf >> (cnt - 15)) & 0x7FFF]; ln = e & 15
                        if ln == 0: raise RarError("kode jarak rendah tidak valid")
                        cnt -= ln; dist += e >> 4
                    else:
                        dist += (buf >> (cnt - dbits)) & ((1 << dbits) - 1)
                        cnt -= dbits
                if dist > 0x100:
                    length += 1
                    if dist > 0x2000:
                        length += 1
                        if dist > 0x40000: length += 1
                old[3] = old[2]; old[2] = old[1]; old[1] = old[0]; old[0] = dist
                last_len = length
                _copy(out, length, dist)
                if len(out) > target + 0x10000: raise RarError("data melebihi ukuran asli")

            if last_block or len(out) >= target: break
            pos_byte = bstart + bsize

        self.old = old; self.last_len = last_len; self.tabs = tabs
        if len(out) - base < usize: raise RarError("data hasil dekompresi kurang")
        result = bytearray(out[base:base + usize])
        for start, length, ftype, ch in filters:
            s = start - base
            if length <= 0 or s < 0 or s + length > len(result): continue
            result[s:s + length] = _filter(bytes(result[s:s + length]), ftype, ch, s)
        if not solid:
            self.hist = bytearray()
        elif len(out) > base + usize:
            del out[base + usize:]
        return bytes(result)


def _slot_len(slot, buf, cnt):
    if slot < 8:
        return 2 + slot, cnt
    lb = slot // 4 - 1
    length = 2 + ((4 | (slot & 3)) << lb)
    length += (buf >> (cnt - lb)) & ((1 << lb) - 1)
    return length, cnt - lb


def _copy(out, length, dist):
    n = len(out)
    if dist > n or dist <= 0: raise RarError("jarak salin tidak valid")
    s = n - dist
    if dist >= length:
        out += out[s:s + length]
    else:
        chunk = bytes(out[s:])
        out += (chunk * (length // dist + 1))[:length]


# ---------------------------------------------------------------- filter ----
def _filter(d, ftype, ch, file_off):
    if ftype == 0:                                   # DELTA
        n = len(d); dst = bytearray(n); src = 0
        for c in range(ch):
            prev = 0
            for p in range(c, n, ch):
                prev = (prev - d[src]) & 255; src += 1
                dst[p] = prev
        return bytes(dst)
    if ftype in (1, 2):                              # E8 / E8E9
        a = bytearray(d); n = len(a); cmp2 = 0xE9 if ftype == 2 else 0xE8
        FS = 0x1000000; cur = 0
        while cur + 4 < n:
            b = a[cur]; cur += 1
            if b == 0xE8 or b == cmp2:
                off = (cur + file_off) % FS
                addr = int.from_bytes(a[cur:cur + 4], 'little')
                if addr & 0x80000000:
                    if ((addr + off) & 0x80000000) == 0:
                        a[cur:cur + 4] = ((addr + FS) & 0xFFFFFFFF).to_bytes(4, 'little')
                else:
                    if ((addr - FS) & 0x80000000) != 0:
                        a[cur:cur + 4] = ((addr - off) & 0xFFFFFFFF).to_bytes(4, 'little')
                cur += 4
        return bytes(a)
    if ftype == 3:                                   # ARM
        a = bytearray(d); n = len(a)
        for cur in range(0, n - 3, 4):
            if a[cur + 3] == 0xEB:
                off = a[cur] | (a[cur + 1] << 8) | (a[cur + 2] << 16)
                off = (off - (file_off + cur) // 4) & 0xFFFFFF
                a[cur] = off & 255; a[cur + 1] = (off >> 8) & 255; a[cur + 2] = (off >> 16) & 255
        return bytes(a)
    raise RarError("tipe filter %d tidak dikenal" % ftype)


# ---------------------------------------------------------------- arsip -----
def _safe_join(dest, name):
    name = name.replace('\\', '/').lstrip('/')
    parts = [p for p in name.split('/') if p not in ('', '.')]
    if any(p == '..' for p in parts): raise RarError("path berbahaya di dalam arsip: %s" % name)
    root = os.path.realpath(dest)
    target = os.path.realpath(os.path.join(dest, *parts)) if parts else root
    if target != root and not target.startswith(root + os.sep):
        raise RarError("path berbahaya di dalam arsip: %s" % name)
    return target


def iter_entries(raw):
    """Hasilkan (nama, is_dir, usize, crc, comp_info, packed_bytes, skip)."""
    if raw[:8] != SIG5:
        raise RarError("bukan RAR5 (RAR versi lama belum didukung)")
    pos = 8; n = len(raw)
    while pos + 7 <= n:
        hstart = pos + 4
        hsz, p = _vint(raw, hstart)
        body = p; hend = p + hsz
        htype, p = _vint(raw, p); hflags, p = _vint(raw, p)
        extra = 0; dsize = 0
        if hflags & 1: extra, p = _vint(raw, p)
        if hflags & 2: dsize, p = _vint(raw, p)
        if htype == 4: raise RarError("arsip RAR terenkripsi tidak didukung")
        if htype == 5: return
        if hflags & 0x18: raise RarError("arsip RAR multi-volume tidak didukung")
        if htype == 1:
            af, p = _vint(raw, p)
            if af & 1: raise RarError("arsip RAR multi-volume tidak didukung")
        elif htype == 2:
            ff, p = _vint(raw, p); usize, p = _vint(raw, p); _attr, p = _vint(raw, p)
            if ff & 2: p += 4
            crc = None
            if ff & 4: crc = struct.unpack_from('<I', raw, p)[0]; p += 4
            comp, p = _vint(raw, p); _host, p = _vint(raw, p); nl, p = _vint(raw, p)
            name = raw[p:p + nl].decode('utf-8', 'replace'); p += nl
            skip = False
            if extra:                                      # area extra di akhir header
                q = hend - extra
                while q < hend:
                    sz, q2 = _vint(raw, q); t, q3 = _vint(raw, q2)
                    if t == 1: raise RarError("file RAR terenkripsi tidak didukung")
                    if t == 5: skip = True                 # symlink / redirect
                    q = q2 + sz
            yield (name, bool(ff & 1), usize, crc, comp, raw[hend:hend + dsize], skip)
        pos = hend + dsize


def extract(path, dest, log=None):
    """Ekstrak arsip RAR5 ke folder dest. Return daftar path yang ditulis."""
    raw = open(path, 'rb').read()
    up = Unpacker(); written = []
    for name, is_dir, usize, crc, comp, packed, skip in iter_entries(raw):
        target = _safe_join(dest, name)
        if is_dir:
            os.makedirs(target, exist_ok=True); continue
        if skip: continue
        version = comp & 0x3F; solid = bool(comp & 0x40); method = (comp >> 7) & 7
        if method == 0:
            data = packed[:usize]
        else:
            if version != 0:
                raise RarError("kompresi RAR versi %d belum didukung" % version)
            data = up.unpack(packed, usize, solid)
        if crc is not None and (zlib.crc32(data) & 0xFFFFFFFF) != crc:
            raise RarError("CRC32 tidak cocok untuk %s" % name)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, 'wb') as f: f.write(data)
        written.append(target)
        if log: log("RAR: %s (%d byte)" % (name, len(data)))
    return written
