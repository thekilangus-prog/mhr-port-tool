# -*- coding: utf-8 -*-
"""Daftar senjata Monster Hunter Rise / Sunbreak untuk 14 tipe: Lance, Great Sword, Sword & Shield,
Hammer, Long Sword, Switch Axe, Gunlance, Dual Blades, Hunting Horn, Insect Glaive, Charge Blade,
Light Bowgun, Heavy Bowgun, dan Bow, ditambah Kinsect (untuk Insect Glaive).

Sumber (wiki mhvuze/MonsterHunterRiseModding):
- Weapon-IDs-(GS,SnS,Ham,Lan)
- Weapon-IDs-(LS,SA,GL,DB,HH)
- Weapon-IDs-(IG,CB,LBG,HBG,Bow)
Tiap baris data: nomor_enum|nomor_model|nama_senjata (ejaan persis wiki).
Urutan dalam satu model mengikuti Sort ID di wiki (urutan tampil di dalam game).

- Weapon ID  = dasar tipe + nomor_enum  (hex 8 digit, mis. Lance 447 -> 084001BF)
- Enum Name  = <awalan>_<nomor_enum 3 digit>  (mis. W_Lance_447)
- Nomor model (3 digit, mis. 105 = Lan105) adalah angka yang dipakai pada nama folder/file model
  dan yang diisi di kolom "ID model tujuan" aplikasi.
"""

# tipe: (awalan enum, dasar Weapon ID, data)
_DATA = {
    'Lance': ('W_Lance', 0x08400000, """
0|018|Iron Lance I
1|018|Iron Lance II
2|018|Millennial Lance
3|058|Paladin Lance I
4|058|Paladin Lance II
5|058|Rampart
6|020|Drill Lance I
7|020|Drill Lance II
8|020|Gigadrill Lance
9|086|Heat Lance I
10|086|Heat Lance II
11|086|Heatstinger
12|007|Babel Spear I
13|007|Babel Spear II
14|007|Elder Babel Spear
15|059|Growling Wyvern I
16|059|Growling Wyvern II
17|059|Roaring Wyvern
18|021|Bone Lance I
19|021|Hard Bone Lance
20|060|Longhorn Spear I
21|060|Longtusk Spear
22|061|Barbarian Tusk I
23|061|Barbarian Fang
24|050|Kamura Spear I
25|050|Kamura Spear II
26|050|Kamura Spear III
27|050|Kamura Spear IV
28|050|Kamura Spear V
29|050|Kamura Ninja Spear
30|085|Rampage Spear I
31|085|Rampage Spear II
32|085|Rampage Spear III
33|085|Rampage Spear S
34|084|Sharktooth Spear I
35|084|Sharktooth Spear II
36|084|Razortooth Spear
37|063|Plegis Needle I
38|063|Plegis Needle II
39|063|Mighty Plegis
40|064|Alacrantze I
41|064|Alacrantze II
42|064|Alacrantze III
43|064|Scorpion Lance
44|062|Fragrance I
45|062|Fragrance II
46|062|Classy Fragrance
47|051|Wind Thief Lance I
48|051|Wind Thief Lance II
49|051|Gale Lance
50|052|Aknosom Lance I
51|052|Aknosom Lance II
52|052|Aknosom Lance III
53|052|Dawnbreaker Lance
54|053|Distension I
55|053|Distension II
56|053|Croaker
57|054|Sinister Spear I
58|054|Sinister Spear II
59|054|Sinister Shadespear
60|055|Goss Lance I
61|055|Goss Lance II
62|055|Abominable Lance
63|056|Azure Elder Spear I
64|056|Azure Elder Spear II
65|056|Abyssal Gale Lance
66|057|Thunderbolt Spear I
67|057|Abyssal Storm Lance
68|083|Redwing Spear I
69|083|Reddnaught Spear
70|065|Azure Crest I
71|065|Azure Crest II
72|065|Azure Crest III
73|065|Great Azure
74|067|Ploshasta I
75|067|Ploshasta II
76|067|Rhenohasta
77|029|Kulu Spear I
78|029|Kulu Spear II
79|029|Kulu Skewer
80|068|Spiral Lance I
81|068|Spiral Lance II
82|068|Spiral Splash
83|069|Rugged Lance I
84|069|Rugged Lance II
85|069|Barroth Carver
86|070|Naag Serpentblade I
87|070|Naag Serpentblade II
88|070|Devta Serpentblade
89|071|Volvi Stroke I
90|071|Volvi Stroke II
91|071|Volvi Sweep
92|030|Pukei Spear I
93|030|Pukei Spear II
94|030|Datura Spear
95|072|Venom Lance I
96|072|Venom Lance II
97|072|Basarios Venom Spear
98|073|Tusk Lance I
99|073|Tusk Lance II
100|073|Sabertooth
101|074|Kadachi Lance I
102|074|Kadachi Lance II
103|074|Shockspear
104|075|Hidden Stinger I
105|075|Hidden Stinger II
106|075|Night Rains Black
107|076|Hana Mo Hana Nare I
108|076|Hana Mo Hana Nare II
109|076|Kimi Ga Kiru
110|001|Red Tail I
111|001|Red Tail II
112|001|Spear of Prominence
113|077|Usurper's Coming I
114|077|Usurper's Coming II
115|077|Despot's Cacophony
116|013|Tiger Stinger I
117|013|Tiger Stinger II
118|013|Tigrex Lance
119|079|Diablos Lance I
120|079|Diablos Lance II
121|079|Diablos Spear
122|002|Icesteel Spear I
123|002|Daora's Fang
124|080|Teostra's Howl I
125|080|Teostra's Roar
126|081|Demon Lance I
127|081|Demon Lance II
128|081|Great Demon Lance
129|006|Rookslayer Lance I
130|006|Rookslayer Lance II
131|006|Bazel Myniad Lance
132|085|Rampage Spear IV
133|085|Rampage Spear V
134|087|Defender Lance I
135|087|Champion Lance
300|100|Kamura Warrior Spear
301|100|Kamura Warrior Spear+
302|100|Fine Kamura Spear
303|113|Duke's Impaler
304|113|Mastlayer
305|055|Abominable Spear
306|055|Abominable Spear+
307|055|Abominable Spike
308|076|Kimi Ga Kiru+
309|076|Kimi Ga Kiru Kasa
310|076|Kimi Ga Kiru Kasa+
311|110|Pure Spear Osaki
312|070|Devta Serpentblade+
313|070|Ouroboros Serpentblade
314|053|Croaker+
315|053|Peeper
316|053|Peeper+
317|051|Gale Lance+
318|051|Great Gale Lance
319|084|Razortooth Spear+
320|084|Spinetooth Spear
321|058|Rampart+
322|058|Watchtower
323|058|Watchtower+
324|007|Elder Babel Spear+
325|007|Lost Babel
327|007|Lost Babel+
328|114|Frostmoon Spirilance
329|114|Frostmoon Spirilance+
330|114|Lunarcry
331|072|Basarios Venom Spear+
334|072|Basalt Venom
335|075|Purple Darklance
336|075|Purple Darklance+
337|075|Avidya Lance
338|059|Roaring Wyvern+
339|059|Raging Wyvern
340|059|Raging Wyvern+
341|074|Shockspear+
342|074|Thunderlance
343|074|Thunderlance+
344|052|Dawnmoon Lance
345|052|Dawnmoon Lance+
346|052|Dawnmoon Piercer
347|069|Niter Spear
348|069|Niter Spear+
349|069|Barroth Borer
350|020|Gigadrill Lance+
351|020|Exadrill Lance
352|020|Exadrill Lance+
353|109|Veil of Lightning
354|109|Veil of Lightning+
355|109|Verdant Lightning
356|071|Volvi Sweep+
357|071|Volvi Swindler
358|071|Volvi Swindler+
359|086|Heatstinger+
361|086|Heat Impaler
365|108|Harbah Lance
366|108|Harbah Lance+
367|108|Turbulent Lance
368|102|Bone Claw Lance
369|102|Bone Claw Lance+
370|102|Red Lord Lance
371|103|Ceanataur Stinger
372|103|Ceanataur Stinger+
373|103|Ceanataur Piercer
374|013|Tigrex Lance+
375|013|Great Tigrex Lance
376|013|Great Tigrex Lance+
377|073|Frosttooth
378|073|Frosttooth+
379|073|Ivory Ice
380|030|Datura Spear+
381|030|Datura Stellaspear
382|030|Datura Stellaspear+
383|001|Spear of Prominence+
384|001|Lejeu Prominence
385|117|Rosenranze
386|117|Rosenranze+
387|117|Rosenbegierde
388|068|Spiral Splash+
389|068|Spiral Vortex
390|068|Spiral Vortex+
391|115|Golm Tower
392|115|Golm Tower+
393|115|Gorkotos
394|067|Rhenohasta+
395|067|Rhenoplos Spear
396|079|Diablos Spear+
397|079|Cera Creos
398|079|Cera Creos+
399|029|Kulu Skewer+
400|029|Kulu Katolos Spear
401|077|Despot's Cacophony+
402|077|Oppressor's Genesis
403|065|Great Azure+
405|065|Bandera Azul
406|054|Sinister Shadespear+
407|054|Mighty Soulscreamer
408|111|Devil's Deliverance
409|081|Great Demon Lance+
410|081|Raging Demon Lance
411|056|Skybore Twister
413|006|Bazel Myniad Queentaker
414|112|Bazel Rocket Rooksearer
415|057|Skybore Discharge
417|002|Daora's Fang+
418|002|Daora's Regulus
419|080|Teostra's Roar+
420|080|Teostra's Fire
421|083|Crimson Sharpwing
422|106|Eiferschild
423|106|Eiferschild+
424|106|Zornesschild
425|107|L'Égide
426|107|Le Paladin
427|116|Abyssal Icicle
428|104|Demonlord Rajang
429|063|Mighty Plegis+
431|063|Mycetic Stupor
432|064|Scorpion Lance+
433|064|Hadrurus Lance
434|062|Classy Fragrance+
436|062|Elegant Fragrance
437|119|Royal Order's Guard
439|119|Royal Order's Guard+
440|120|Antique Machina L
441|121|Dark Lance
442|121|Dark Lance+
443|121|Dark Spear
444|118|Kaktus Begierde
445|101|Silver Prominence
447|105|Dubhe's Asterism
454|087|Champion Lance II
455|087|Champion Lance III
456|087|Guardian Lance
460|122|Lost Code: Mia
461|124|Luzifer/Sage
462|123|Stuffed Malzeno
463|125|Knightly Ectis
464|126|Ominous Cloud
465|127|Silver Stabber
"""),
    'Great Sword': ('W_GreatSword', 0x08100000, """
0|024|Buster Sword I
1|024|Buster Blade
2|059|Iron Sword I
3|059|Steel Sword
4|025|Axeblade I
5|025|Axeblade II
6|025|Colossal Axeblade
7|060|Chrome Razor I
8|060|Chrome Quietus
9|027|Bone Cleaver I
10|027|Bone Slasher
11|028|Jawblade I
12|028|Giant Jawblade
13|061|Wyvern Fang I
14|061|Great Wyvern Fang
15|026|Golem Blade I
16|026|Blade of Talos
17|062|Barbaroi Blade I
18|062|Barbaroi Blade II
19|062|Crimson Goat
20|050|Kamura Cleaver I
21|050|Kamura Cleaver II
22|050|Kamura Cleaver III
23|050|Kamura Cleaver IV
24|050|Kamura Cleaver V
25|050|Kamura Ninja Cleaver
26|086|Rampage Cleaver I
27|086|Rampage Cleaver II
28|086|Rampage Cleaver III
29|086|Rampage Cleaver S
30|063|Frozen Speartuna I
31|063|Frozen Speartuna II
32|063|Freezer Speartuna
33|087|Ninja Parasol I
34|087|Ninja Parasol II
35|087|Dragonslayer Parasol
36|065|Cat's Soul I
37|065|Cat's Soul II
38|065|Cat's Curse
39|064|Wyvern's Perch I
40|064|Wyvern's Perch II
41|064|Roguish Deathcap
42|083|Sleepy Shellblade I
43|083|Sleepy Shellblade II
44|083|Soporific Shellblade
45|051|Izuchi Blade I
46|051|Izuchi Blade II
47|051|Snapper Blade
48|052|Aknosom Blade I
49|052|Aknosom Blade II
50|052|Daybreak Cleaver
51|053|Tetranadon Edge I
52|053|Tetranadon Edge II
53|053|Tetranadon Cutter
54|054|Frilled Blade I
55|054|Frilled Blade II
56|054|Illusory Frilled Blade
57|055|Sinister Blade I
58|055|Sinister Blade II
59|055|Sinister Shadowblade
60|056|Gossblade I
61|056|Gossblade II
62|056|Abominable Great Sword
63|057|Azure Elder Great Sword I
64|057|Azure Elder Great Sword II
65|057|Abyssal Galeblade
66|058|Thunderbolt Great Sword I
67|058|Abyssal Storm Cleaver
68|084|Redwing Claymore I
69|084|Reddnaught Claymore
70|066|Snowclad I
71|066|Snowclad II
72|066|Lagombi Charlotte
73|068|Cataclysm Sword I
74|068|Cataclysm Sword II
75|068|Cataclysm Blade
76|069|Carapace Sword I
77|069|Carapace Sword II
78|069|Carapace Blade
79|070|Khezu Shock Sword I
80|070|Khezu Shock Sword II
81|070|Khezu Shock Blade
82|071|Deadly Serpentblade I
83|071|Deadly Serpentblade II
84|071|Poison Serpentblade
85|030|Pukei Edge I
86|030|Pukei Edge II
87|030|Datura Cleaver
88|085|Jyura Mudblade I
89|085|Jyura Mudblade II
90|085|Terracutter
91|072|Valkyrie Blade I
92|072|Valkyrie Blade II
93|072|Sieglinde
94|011|Icicle Fang I
95|011|Icicle Fang II
96|011|Paladire
97|005|Flammenzahn I
98|005|Flammenzahn II
99|005|Gnashing Flammenzahn
100|074|Hidden Blade I
101|074|Hidden Blade II
102|074|Dark of Night
103|075|Hanayako Yohino I
104|075|Hanayako Yohino II
105|075|Akanesasu
106|003|Red Wing I
107|003|Red Wing II
108|003|Rathalos Firesword
109|076|Usurper's Storm I
110|076|Usurper's Storm II
111|076|Despot's Blackstorm
112|015|Tiger Jawblade I
113|015|Tiger Jawblade II
114|015|Tigrex Great Sword
115|078|Quarrel Hornsword I
116|078|Quarrel Hornsword II
117|078|Feud Hornsword
118|001|Icesteel Edge I
119|001|Daora's Decimator
120|079|Teostra Blade I
121|079|King Teostra Blade
122|080|Grand Shamshir I
123|080|Foreboding Shamshir
124|081|Demon Rod I
125|081|Demon Rod II
126|081|Great Demon Rod
127|067|Hack Blade I
128|067|Hack Blade II
129|067|Jaggi Greatblade
130|086|Rampage Cleaver IV
131|086|Rampage Cleaver V
132|088|Defender Great Sword I
133|088|Champion Great Sword
300|100|Kamura Warrior Cleaver
301|100|Kamura Warrior Cleaver+
302|100|Fine Kamura Cleaver
303|056|Abominable Snowblade
304|056|Abominable Snowblade+
305|056|Abominable Frostblade
306|075|Akanesasu+
307|075|Akanesasu Divider
308|075|Akanesasu Divider+
309|110|Pure Sword Omurasaki
313|069|Carapace Buster
314|069|Carapace Buster+
315|069|Barroth Smasher
316|015|Tigrex Great Sword+
317|015|Tigrex Supreme Sword
318|015|Tigrex Supreme Sword+
319|070|Khezu Shock Blade+
320|070|Khezu Shock Full
321|070|Khezu Shock Full+
322|051|Snapper Blade+
323|051|Blower's Blade
324|071|Poison Serpentblade+
325|071|Snakesmaw
326|074|Gloom of Night
327|074|Gloom of Night+
328|074|Avidya Great Sword
329|054|Illusory Frilled Blade+
330|054|Nightmare Frilled Blade
331|054|Nightmare Frilled Blade+
332|112|Bloom Snow Blade
333|112|Bloom Snow Blade+
334|112|Flicker Blizzard Blade
335|060|Chrome Hell
336|060|Chrome Hell+
337|060|Chrome Heaven
338|109|Astalos Crashblade
339|109|Astalos Crashblade+
340|109|Astalos Arcblade
341|062|Inferno Goat
342|062|Inferno Goat+
343|062|Blood Baph
344|030|Datura Cleaver+
345|030|Datura Slasher
346|030|Datura Slasher+
347|011|Glaciator
348|011|Glaciator+
349|011|Blizzard Biter
350|114|Sword of Winter Moon
351|114|Sword of Winter Moon+
352|114|Vadel Frostedge
353|052|Dawnmoon Cleaver
354|052|Dawnmoon Cleaver+
355|052|Dawnmoon Hopebeam
356|053|Tetranadon Cutter+
357|053|True Tetranadon Cutter
358|053|True Tetranadon Cutter+
359|028|Great Wyvern Fang+
360|028|Wyvern Gnasher
361|028|Wyvern Gnasher+
362|102|Red Pincer
363|102|Red Pincer+
364|102|Great Pincer
365|103|Ceanataur Blade
366|103|Ceanataur Blade+
367|103|Killer's Scythe
368|026|Blade of Talos+
369|026|Blade of Tartarus
370|026|Blade of Tartarus+
371|108|Cheda Blade
372|108|Cheda Blade+
373|108|Impudent Cheda
374|072|Sieglinde+
375|072|High Sieglinde
376|072|High Sieglinde+
377|117|Rosenbrett
378|117|Rosenbrett+
379|117|Rosenkraft
380|085|Terracutter+
381|085|Valtos Rapier
382|085|Valtos Rapier+
383|003|Rathalos Firesword+
384|003|Rathalos Shriekedge
385|078|Feud Hornsword+
386|078|Vendetta Hornsword
387|078|Vendetta Hornsword+
388|067|Jaggi Greatblade+
389|067|Avallo Blade
390|005|Gnashing Flammenzahn+
391|005|Lohenzahn
392|005|Lohenzahn+
393|076|Despot's Blackstorm+
394|076|Oppressor's Forger
395|068|Cataclysm Blade+
396|068|Aquatic Cataclysm
397|068|Aquatic Cataclysm+
398|115|Golm Blade
399|115|Golm Blade+
400|115|Great Gorgigas
401|066|Lagombi Charlotte+
402|066|Lagombi Decider
403|055|Sinister Shadowblade+
404|055|Mighty Soulquencher
405|111|Azure Blaze Great Sword
406|081|Great Demon Rod+
407|081|Great Demon Hot Rod
408|057|Skysplit Hurricane
410|058|Skysplit Thunderstorm
412|001|Daora's Decimator+
413|001|Daora's Tughril Beg
414|079|King Teostra Blade+
415|079|Teostra del Sol
416|080|Foreboding Shamshir+
417|080|Dreaded Shamshir
418|084|Crimson Vastwing
419|106|Schattenstolz
420|106|Schattenstolz+
421|106|Verhängnisstolz
422|107|L'Apothéose
423|107|L'Origine
424|116|Abyssal Eruption
425|104|Demonlord Goldrod
426|064|Roguish Deathcap+
427|064|Lordly Deathcap
428|083|Soporific Shellblade+
429|083|Dreamdiver
430|063|Freezer Speartuna+
431|063|Xiphias Gladius
432|087|Dragondance Parasol
433|087|Dragondance Parasol+
434|065|Cat's Curse+
435|065|Cat's King
436|119|Royal Order's Great Sword
438|119|Royal Order's Great Sword+
439|120|Antique Machina GS
440|113|Duke's Claymore
441|113|Decapitator Schneiden
442|118|Kaktus Kraft
443|101|Rathalos Gleamsword
445|105|Merak's Asterism
455|088|Champion Great Sword II
456|088|Champion Great Sword III
457|088|Guardian Great Sword
461|121|Lost Code: Asca
462|123|Anfang/Fin
463|122|Stuffed Rathalos
464|124|Winged Seraphyd
465|125|Roilcloud Sword
466|126|Silver Sunderer
"""),
    'Sword & Shield': ('W_ShortSword', 0x08200000, """
0|018|Hunter's Knife I
1|018|Hunter's Knife II
2|018|Fighter Sword
3|058|Frost Edge I
4|058|Frost Edge II
5|058|Hi Frost Edge
6|019|Iron Beater I
7|019|Iron Beater II
8|019|Smithy's Pride
9|059|Ninja Sword I
10|059|Hi Ninja Sword
11|060|Odyssey Blade I
12|060|Odyssey Blade II
13|060|Master Odyssey
14|021|Bone Kukri I
15|021|Bone Kukri II
16|021|Chief Kukri
17|022|Bone Barong I
18|022|Bone Barong II
19|022|Grand Barong
20|061|Bone Tabar I
21|061|Bone Tabar II
22|061|Ragdos Tabar
23|050|Kamura Sword I
24|050|Kamura Sword II
25|050|Kamura Sword III
26|050|Kamura Sword IV
27|050|Kamura Sword V
28|050|Kamura Ninja Sword
29|089|Rampage Sword I
30|089|Rampage Sword II
31|089|Rampage Sword III
32|089|Rampage Sword S
33|063|Catspaw I
34|063|Catspaw II
35|063|Catburglar
36|088|Sleepy Shellsword I
37|088|Sleepy Shellsword II
38|088|Waking Nightmare
39|051|Izuchi Sickle I
40|051|Izuchi Sickle II
41|051|Snapper Sickle
42|052|Cunning Riposte I
43|052|Cunning Riposte II
44|052|Guard Breaker
45|053|Exorcising Sword I
46|053|Exorcising Sword II
47|053|Shaucha Pureblade
48|054|Sinister Sword I
49|054|Sinister Sword II
50|054|Sinister Shadekeeper
51|055|Mincing Blade I
52|055|Mincing Blade II
53|055|Chef's Knife
54|056|Azure Elder Sword I
55|056|Azure Elder Sword II
56|056|Abyssal Gale Shredder
57|057|Thunderbolt Sword I
58|057|Abyssal Storm Shredder
59|087|Redwing Swiftblade I
60|087|Vermilion Orgul
61|064|Brash Buddies I
62|064|Brash Buddies II
63|064|Cocky Comrades
64|065|Secta Nulo I
65|065|Secta Unu
66|069|Secta Nulo Red I
67|069|Secta Nulo Red II
68|069|Secta Unu Red
69|067|Secta Nulo Yellow I
70|067|Secta Unu Yellow
71|068|Secta Nulo White I
72|068|Secta Unu White
73|066|Secta Nulo Green I
74|066|Secta Unu Green
75|070|Secta Nulo Black I
76|070|Secta Nulo Black II
77|070|Secta Unu Black
78|071|Hypnos Knife I
79|071|Hypnos Knife II
80|071|Morpheus Knife
81|072|Soldier's Dagger I
82|072|Soldier's Dagger II
83|072|Commander's Dagger
84|073|Dirty Baron I
85|073|Dirty Baron II
86|073|Dirty Marquis
87|074|Royal Claw I
88|074|Royal Claw II
89|074|Royal Ludroth Claw
90|075|Carapace Mace I
91|075|Carapace Mace II
92|075|Barroth Club
93|076|Khezu Razor I
94|076|Khezu Razor II
95|076|Painful Razor
96|077|Lava Pick I
97|077|Lava Pick II
98|077|Burly Beak
99|030|Pukei Sword I
100|030|Pukei Sword II
101|030|Venomedge
102|003|Princess Rapier I
103|003|Princess Rapier II
104|003|Queen Rapier
105|078|Icicle Spike I
106|078|Icicle Spike II
107|078|Nardebosche
108|006|Flammensucher I
109|006|Flammensucher II
110|006|Gnashing Flammensucher
111|014|Hidden Edge I
112|014|Hidden Edge II
113|014|Flash in the Night
114|080|Hana no Nagoriwo I
115|080|Hana no Nagoriwo II
116|080|Kurenawi Ougi
117|081|Djinn I
118|081|Djinn II
119|081|Blazing Falchion
120|082|Usurper's Firebolt I
121|082|Usurper's Firebolt II
122|082|Despot's Crookbolt
123|010|Rex Talon I
124|010|Rex Talon II
125|010|Tigrex Sword
126|084|Studded Club I
127|084|Studded Club II
128|084|Spiked Bat
129|085|Icesteel Dagger I
130|085|Daora's Razor
131|001|Teostra's Spada I
132|001|Teostra's Emblem
133|086|Rajang Club I
134|086|Rajang Club II
135|086|Banned Rajang Club
136|089|Rampage Sword IV
137|089|Rampage Sword V
138|091|Defender Sword I
139|091|Champion Sword
300|100|Kamura Warrior Sword
301|100|Kamura Warrior Sword+
302|100|Fine Kamura Sword
303|014|Nightbloom
304|014|Nightbloom+
305|014|Avidya Edge
306|080|Kurenawi Ougi+
307|080|Kurenawi Kunpuu
308|080|Kurenawi Kunpuu+
309|110|Pure Silver Fan Hime
310|053|Crown of the Protector
311|053|Crown of the Protector+
312|053|Heavenly King's Sword
313|112|Shaucha Gloryblade
314|112|Shaucha Gloryblade+
315|112|Shaucha Divine Gloryblade
316|082|Despot's Crookbolt+
317|082|Oppressor's Bounty
318|073|Dirty Marquis+
319|073|Dirty Graf
320|074|Royal Ludroth Claw+
321|074|Royal Waterclaw
322|074|Royal Waterclaw+
323|115|Golm Sword
324|115|Golm Sword+
325|115|Giant's Sword "Goltsneit"
326|010|Tigrex Sword+
327|010|Great Tigrex Sword
328|010|Great Tigrex Sword+
329|058|Crystallized Edge
330|058|Crystallized Edge+
331|058|Permafrost Edge
332|114|Frostmoon Hatchet
333|114|Frostmoon Hatchet+
334|114|Winter's Feast Hatchet
338|109|Sarganas Rapier
339|109|Sarganas Rapier+
340|109|Astalos Rapier
341|113|Duke's Baselard
342|113|Bloodlust Blade
343|072|Commander's Dagger+
344|072|Elite Dagger
345|060|Oresteia
346|060|Oresteia+
347|060|Agamemnon
348|030|Venomedge+
349|030|Datura Splitter
350|030|Datura Splitter+
351|081|Blazing Falchion+
352|081|Enspirited Ifrit
353|078|Nardeglacon
354|078|Nardeglacon+
355|078|Never Event
356|052|Guard Breaker+
357|052|True Guard Breaker
358|052|True Guard Breaker+
359|076|Painful Razor+
360|076|Dread Razor
361|076|Dread Razor+
362|071|Morpheus Knife+
363|071|Karmanight
364|022|Grand Barong+
365|022|Barong Kutot
366|022|Barong Kutot+
367|103|Dual Carapace
368|103|Dual Carapace+
369|103|Dual Scissors
370|003|Queen Rapier+
371|003|Empress Rapier
372|003|Empress Rapier+
373|117|Rosenmesser
374|117|Rosenmesser+
375|117|Rosengedien
376|061|Ragdos Tabar+
377|061|Bonebreaker Tabar
378|061|Bonebreaker Tabar+
379|108|Naab Sword
380|108|Naab Sword+
381|108|Feral Fangs
382|075|Barrotherang
383|075|Barrotherang+
384|075|Pneumatic Drillblade
385|084|Spiked Bat+
386|084|Barbarian Terror
387|084|Barbarian Terror+
388|006|Gnashing Flammensucher+
389|006|Lohensieger
390|006|Lohensieger+
391|055|Chef's Best Knife
392|055|Chef's Best Knife+
393|055|Chef's Ultimate Knife
394|051|Snapper Sickle+
395|051|Blower's Scythes
396|077|Burly Beak+
397|077|Bruising Beak
398|068|Secta Du White
399|068|Secta Tre White
400|070|Secta Du Black
401|070|Secta Tre Black
402|066|Secta Du Green
403|066|Secta Tre Green
404|067|Secta Du Yellow
405|067|Secta Tre Yellow
406|069|Secta Du Red
407|069|Secta Tre Red
408|054|Sinister Shadekeeper+
409|054|Tormented Shadekeeper
410|111|Spirit Stealer
411|086|Banned Rajang Club+
412|086|Cursed Rajang Club
413|056|Windchaser
415|057|Atomic Mind
417|085|Daora's Razor+
418|085|Daora's Maelstrom
419|001|Teostra's Emblem+
420|001|Teostra's Medal
421|087|Gates of Heaven
422|106|Sucher-Ankh
423|106|Sucher-Ankh+
424|106|Sieger-Ankh
425|107|Le Détecteur
426|107|Le Limier
427|116|Abyssal Sunburst
428|104|Demonlord Bludgeon
429|088|Waking Nightmare+
430|088|Dreamwaver
431|063|Catburglar+
432|063|Catlike Tread
433|059|Hi Ninja Sword+
434|059|Ninja Master Sword
435|119|Royal Order's Sword
437|119|Royal Order's Sword+
438|120|Antique Machina SS
439|118|Kaktus Gedeihen
440|102|Platinum Dawn
441|101|Lunatic Rose
443|105|Phecda's Asterism
450|091|Champion Sword II
451|091|Champion Sword III
452|091|Guardian Sword
456|121|Lost Code: Carnhan
457|123|Lügen/Vérité
458|122|Stuffed Zinogre
459|124|Noble Ana Palas
460|125|Ominous Treasure
461|126|Silver Separator
"""),
    'Hammer': ('W_Hammer', 0x08300000, """
0|019|Iron Hammer I
1|019|Iron Devil
2|018|War Hammer I
3|018|War Mace
4|059|Gun Hammer I
5|059|Gun Hammer II
6|059|Deadeye Revolver
7|060|Great Nova I
8|060|Great Nova II
9|060|Super Nova
10|007|Frozen Core I
11|007|Frozen Core II
12|007|Cocytus
13|061|Devil Masher I
14|061|Devil Masher II
15|061|Iron Devil's Soul
16|062|War Stamp I
17|062|War Basher
18|063|Bone Hammer I
19|063|Bone Hammer II
20|063|Hard Bone Hammer
21|064|Cyclo-Hammer I
22|064|Cyclo-Hammer II
23|064|Atlas Hammer
24|020|Bone Bludgeon I
25|020|Bone Bludgeon II
26|020|Heavy Bone Bludgeon
27|050|Kamura Hammer I
28|050|Kamura Hammer II
29|050|Kamura Hammer III
30|050|Kamura Hammer IV
31|050|Kamura Hammer V
32|050|Kamura Ninja Hammer
33|089|Rampage Hammer I
34|089|Rampage Hammer II
35|089|Rampage Hammer III
36|089|Rampage Hammer S
37|065|Teddybear I
38|065|Teddybear II
39|065|Sleepy Bear
40|068|Graceful Death I
41|068|Graceful Death II
42|068|Graceful Death III
43|068|Yadora Morte
44|066|Pumpking I
45|066|Pumpking II
46|066|Jack-'o-lantern King
47|051|Izuchi Hammer I
48|051|Izuchi Hammer II
49|051|Snapper Hammer
50|052|Five-Pronged Hammer I
51|052|Five-Pronged Hammer II
52|052|Great Pronged Hammer
53|053|Frilled Blow I
54|053|Frilled Blow II
55|053|Illusory Frilled Blow
56|054|Sinister Hammer I
57|054|Sinister Hammer II
58|054|Sinister Shade Hammer
59|055|Yeti Hammer I
60|055|Yeti Hammer II
61|055|Yeti Hammer III
62|055|Abominable Hammer
63|056|Almudron Hammer I
64|056|Almudron Hammer II
65|056|Doom Bringer Hammer
66|057|Azure Elder Hammer I
67|057|Azure Elder Hammer II
68|057|Abyssal Gale Mauler
69|058|Thunderbolt Hammer I
70|058|Abyssal Storm Mauler
71|088|Redwing Drill I
72|088|Reddnaught Hammer
73|069|Egg Hammer I
74|069|Egg Hammer II
75|069|Gargwa Hammer
76|070|Unbearable Hammer I
77|070|Unbearable Hammer II
78|070|Barbearic Hammer
79|071|Wroggi Hammer I
80|071|Wroggi Hammer II
81|071|Dirty Hammer
82|027|Kulu Bludgeon I
83|027|Kulu Bludgeon II
84|027|Kulu Crusher
85|072|Droth Splashhammer I
86|072|Droth Splashhammer II
87|072|Ludroth Dousehammer
88|073|Carapace Hammer I
89|073|Carapace Hammer II
90|073|Barroth Hammer
91|074|Bag o' Horrors I
92|074|Bag o' Horrors II
93|074|Bag o' Thunder
94|075|Calamitous Portent I
95|075|Calamitous Portent II
96|075|Catastrophic Portent
97|076|Binding Bludgeon I
98|076|Binding Bludgeon II
99|076|Armored Gogue
100|028|Pukei Hammer I
101|028|Pukei Hammer II
102|028|Datura Club
103|077|Basarios Blow I
104|077|Basarios Blow II
105|077|Basarios Bash
106|043|Glacial Bash I
107|043|Glacial Bash II
108|043|Glacial Crunch
109|030|Flaming Fury I
110|030|Flaming Fury II
111|030|Phoenix Fury
112|012|Hidden Breaker I
113|012|Hidden Breaker II
114|012|Night Eternal
115|079|Purity Hammer I
116|079|Purity Hammer II
117|079|Sinter Hammer
118|080|Red Bludgeon I
119|080|Red Bludgeon II
120|080|Huracan Hammer
121|081|Usurper's Thunder I
122|081|Usurper's Thunder II
123|081|Despot's Crackle
124|082|Striped Striker I
125|082|Striped Striker II
126|082|Tigrex Hammer
127|083|Diablos Hammer I
128|083|Diablos Hammer II
129|083|Diablos Tail
130|001|Icesteel Hammer I
131|001|Daora's Colossus
132|084|Teostra Cratermaker I
133|084|Teostra Cratergouger
134|085|Genie's Expanse I
135|085|Diamalto's Dream
136|086|Mane Malice I
137|086|Mane Malice II
138|086|Mane Malice Rajang
139|089|Rampage Hammer IV
140|089|Rampage Hammer V
141|090|Defender Hammer I
142|090|Champion Hammer
300|100|Kamura Warrior Hammer
301|100|Kamura Warrior Hammer+
302|100|Fine Kamura Hammer
303|114|Duke Smiter
304|114|Tooth Grinder
305|079|Sinter Hammer+
306|079|Enlightenment Hammer
307|079|Enlightenment Hammer+
308|109|Pure Hammer Mitama
309|076|Armored Gogue+
310|076|Armored Megagogue
311|076|Armored Megagogue+
312|056|Hell Bringer Hammer
313|056|Hell Bringer Hammer+
314|056|Doomsday Hammer
315|113|Magma Masher
451|113|Magma Masher+
316|113|Volcanic Impact
317|052|Mighty Pronged Hammer
318|052|Mighty Pronged Hammer+
319|052|Hallowed Pronged Hammer
320|111|Higher Pronged Hammer
321|111|Higher Pronged Hammer+
322|111|Peak Pronged Hammer
323|071|Dirty Hammer+
324|071|Heavy Hammer
325|059|Break Revolver
326|059|Break Revolver+
327|059|Burst Revolver
328|060|Super Nova+
329|060|Hyper Nova
330|060|Hyper Nova+
331|108|Astalos Sparkler
332|108|Astalos Sparkler+
333|108|Astalos Striker
334|082|Tigrex Hammer+
335|082|Huge Tigrex Hammer
336|082|Huge Tigrex Hammer+
337|030|Phoenix Fury+
338|030|Phoenix Testament
339|030|Phoenix Testament+
340|043|Glacial Blanche
341|043|Glacial Blanche+
342|043|Avalanche Ritter
343|027|Kulu Crusher+
344|027|Kulu Katolos Stick
345|061|Iron Devil's Respect
346|061|Iron Devil's Respect+
347|061|Iron Giant's Soul
348|070|Barbearic Hammer+
349|070|Bearly Eyhammer
350|053|Illusory Frilled Blow+
351|053|Nightmare Frilled Blow
352|053|Nightmare Frilled Blow+
353|112|Bloom Snow Blow
354|112|Bloom Snow Blow+
355|112|Flicker Blizzard Blow
356|074|Bag o' Thunder+
357|074|Bag o' Booms
358|074|Bag o' Booms+
359|007|Niflheim
360|007|Niflheim+
361|007|Pykrete Punisher
362|115|Hammer of Winter Moon
363|115|Hammer of Winter Moon+
364|115|Hammer of Snowfallen
365|102|Ceanataur Head Axe
366|102|Ceanataur Head Axe+
367|102|Big Blue Chopper
368|083|Diablos Maul+
369|083|Finishing Hammer
370|083|Finishing Hammer+
371|064|Atlas Hammer+
372|064|Atlas Crusher
373|064|Atlas Crusher+
374|107|Matraca Hammer
375|107|Matraca Hammer+
376|107|Argyl Hammer
377|028|Datura Club+
378|028|Datura Pounder
379|028|Datura Pounder+
380|080|Huracan Hammer+
381|080|Rathalos Cosh
382|118|Rosenhammer
383|118|Rosenhammer+
384|118|Rosenunwetter
385|055|Abominable Buster
386|055|Abominable Buster+
387|055|Abominable Avalanche
388|081|Despot's Crackle+
389|081|Oppressor's Sway
390|075|Catastrophic Portent+
391|075|Cataclysmic Portent
392|072|Ludroth Dousehammer+
393|072|Lorelei
394|072|Lorelei+
395|116|Golm Gavel
396|116|Golm Gavel+
397|116|Gornir
398|051|Snapper Hammer+
399|051|Blower's Hammer
400|012|Endless Eternia
401|012|Endless Eternia+
402|012|Avidya Breaker
403|073|Barroth Charger
404|073|Barroth Charger+
405|073|Barroth Momentum
406|054|Sinister Shade Hammer+
407|054|Mighty Souldevourer
408|110|Devil's Die
409|069|Gargwa Hammer+
410|069|Gargegg Hammer
411|086|Mane Malice Rajang+
412|086|Mane Master Rajang
413|057|Skyfold Boldblow
414|058|Skyfold Furyflash
415|001|Daora's Colossus+
416|001|Daora's Hyperborea
417|084|Teostra Cratergouger+
418|084|Teostra de la Torre
419|085|Diamalto's Dream+
420|085|Diamgolgo's Phantasm
421|088|Crimson Forcewing
422|105|Wuchtblick
423|105|Wuchtblick+
424|105|Ächtungsblick
425|106|Le Jugement
426|106|La Terre
427|117|Abyssal Windstorm
428|103|Demonlord Sledge
429|065|Sleepy Bear+
430|065|Dreamy Bear
431|068|Yadora Morte+
432|068|Dark Morte
433|066|Jack-'o-lantern King+
434|066|Magic Pumpking
435|120|Royal Order's Bludgeon
436|120|Royal Order's Bludgeon+
437|121|Antique Machina H
438|119|Kaktus Unwetter
439|101|Leonid Starcrusher
441|104|Ascella's Asterism
448|090|Champion Hammer II
449|090|Champion Hammer III
450|090|Guardian Hammer
455|122|Lost Code: Mjo
456|124|Vergehen/Naissance
457|123|Stuffed Diablos
458|125|Victorious Northlein
459|126|Incubus Hammer
460|127|Silver Splatterer
"""),
    'Long Sword': ('W_LongSword', 0x08500000, """
0|019|Iron Katana I
1|019|Iron Katana II
2|019|Iron Gospel
3|059|Eager Cleaver I
4|059|Eager Cleaver II
5|059|Devil Slicer
6|060|Guardian Sword I
7|060|Guardian Sword II
8|060|Imperial Sword
9|061|Chillblade I
10|061|Chillblade II
11|061|Rimeblossom
12|021|Keen Edge I
13|021|Keen Edge II
14|021|Julienne Blade
15|024|Bone Scythe I
16|024|Bone Scythe II
17|024|Bone Reaper
18|062|Dark Scythe I
19|062|Tormentor
20|063|Serrated Jaw I
21|063|Serrated Jaw II
22|063|Serrated Maw
23|064|Scythe of Menace I
24|064|Scythe of Menace II
25|064|Big Menacing Scythe
26|050|Kamura Blade I
27|050|Kamura Blade II
28|050|Kamura Blade III
29|050|Kamura Blade IV
30|050|Kamura Blade V
31|050|Kamura Ninja Blade
32|089|Rampage Blade I
33|089|Rampage Blade II
34|089|Rampage Blade III
35|089|Rampage Blade S
36|088|Hand-Me-Down Sword I
37|088|Hand-Me-Down Sword II
38|088|Kamura's Inheritance
39|067|Cawscythe I
40|067|Cawscythe II
41|067|Cawscythe III
42|067|Squawkscythe
43|051|Wind Thief Scimitar I
44|051|Wind Thief Scimitar II
45|051|Gale Scimitar
46|052|Aknosom Sabre I
47|052|Aknosom Sabre II
48|052|Daybreak Blade
49|053|Frilled Slash I
50|053|Frilled Slash II
51|053|Illusory Frilled Slash
52|054|Sinister Long Sword I
53|054|Sinister Long Sword II
54|054|Sinister Shade Sword
55|055|Almudron Blade I
56|055|Almudron Blade II
57|055|Doom Bringer Blade
58|056|Azure Elder Long Sword I
59|056|Azure Elder Long Sword II
60|056|Abyssal Gale Sword
61|057|Thunderbolt Long Sword I
62|057|Abyssal Storm Sword
63|087|Redwing Long Sword I
64|087|Reddnaught Blade
65|068|Anteka Blade I
66|068|Anteka Blade II
67|068|Anteka Rack
68|069|Arzuros Naginata I
69|069|Arzuros Naginata II
70|069|Arzuros Strikequill
71|070|Ananta Blade I
72|070|Ananta Blade II
73|070|Shadow Slasher
74|071|Ivory Rabbit I
75|071|Ivory Rabbit II
76|071|Iced Rabbit
77|072|Canine Katana I
78|072|Canine Katana II
79|072|Gnash Katana
80|073|Wroggi Sword I
81|073|Wroggi Sword II
82|073|Poison Barb
83|030|Kulu Katana I
84|030|Kulu Katana II
85|030|Kulu Slicer
86|074|Drowning Shaft I
87|074|Drowning Shaft II
88|074|Douser Bardiche
89|075|Castello Saif I
90|075|Castello Saif II
91|075|Castellum Long Sword
92|031|Jyura Saber I
93|031|Jyura Saber II
94|031|Jyura Reaver
95|076|Gigant Makra I
96|076|Gigant Makra II
97|076|Titanic Makra
98|007|Wyvern Blade Verde I
99|007|Wyvern Blade Verde II
100|007|Wyvern Blade Holly
101|077|Bastine Edge I
102|077|Bastine Edge II
103|077|Bastizan Edge
104|032|Spark Slicer I
105|032|Spark Slicer II
106|032|Shocking Slicer
107|033|Flammenschwert I
108|033|Flammenschwert II
109|033|Fervid Flammenschwert
110|015|Hidden Saber I
111|015|Hidden Saber II
112|015|Deepest Night
113|079|Kakaru Kumo Naki I
114|079|Kakaru Kumo Naki II
115|079|Tamonowo
116|003|Wyvern Blade Blood I
117|003|Wyvern Blade Blood II
118|003|Wyvern Blade Maple
119|080|Usurper Boltslicer I
120|080|Usurper Boltslicer II
121|080|Despot Boltbreaker
122|014|Tigrine Edge I
123|014|Tigrine Edge II
124|014|Tigrine Need
125|082|Icesteel Blade I
126|082|Daora's Raid
127|083|Imperial Saber I
128|083|Imperial Shimmer
129|084|Mirage Finsword I
130|084|Phantom Mirage
131|085|Demon Halberd I
132|085|Demon Halberd II
133|085|Great Demon Halberd
134|006|Rookslayer Saber I
135|006|Rookslayer Saber II
136|006|Bazel Varga Rookslayer
137|089|Rampage Blade IV
138|089|Rampage Blade V
139|091|Defender Long Sword I
140|091|Champion Long Sword
141|090|Azure Star Blade I
142|090|Azure Star "Dragon Dance"
300|100|Kamura Warrior Rapier
301|100|Kamura Warrior Rapier+
302|100|Fine Kamura Rapier
303|080|Despot Boltbreaker+
304|080|Oppressor's Law
305|052|Dayspring Blade
306|052|Dayspring Blade+
307|052|Dawnlight Blade
308|071|Iced Rabbit+
309|071|Inaba's Thorns
310|060|Imperial Sword II
311|060|Imperial Sword III
312|060|Adamantine Lodestar
313|116|Duke's Sinclair
314|116|Fissureforce
315|075|Barroth Castillo
316|075|Barroth Castillo+
317|075|Barroth Velberg
318|076|Titanic Makra+
319|076|Makra's Basalt
320|055|Death Bringer Blade
321|055|Death Bringer Blade+
322|055|Abyss Bringer Blade
323|114|Magma Disaster
324|114|Volcanic Apocalypse
328|110|Wyvern Blade "Peridot"
329|110|Wyvern Blade "Peridot"+
330|110|Wyvern Blade "Alexa"
331|014|Tigrine Need+
332|014|Desperate Roar
333|014|Desperate Roar+
334|079|Tamonowo+
335|079|Tamonowo Zekkarei
336|079|Tamonowo Zekkarei+
337|111|Pure Sword Ichimonji
338|015|Darkest Night
339|015|Darkest Night+
340|015|Avidya Saber
341|059|Devil Slicer+
342|059|True Devil Slicer
343|059|True Devil Slicer+
344|030|Kulu Slicer+
345|030|Kulu Katolos Seif
346|061|Icebloom
347|061|Icebloom+
348|061|Frostveldt
349|117|Frostmoon Paleblade
350|117|Frostmoon Paleblade+
351|117|Moonbrand "Lua Cheia"
352|007|Wyvern Blade Holly+
353|007|Wyvern Blade "Jade"
354|007|Wyvern Blade "Jade"+
355|120|Rosenfader
356|120|Rosenfader+
357|120|Rosenhimmel
358|003|Wyvern Blade "Maple"+
359|003|Wyvern Blade "Scarlet"
360|072|Gnash Katana+
361|072|Sunderer
362|072|Sunderer+
363|109|Khanga Edge
364|109|Khanga Edge+
365|109|Khanga Rebellion
366|124|Black Katana Mk.I
367|124|Black Katana Mk.I+
368|124|Final Black Katana
369|033|Fervid Flammenschwert+
370|033|Lohenschwert
371|033|Lohenschwert+
372|077|Bastiana Saber
373|077|Bastiana Saber+
374|077|Amberfang Gelfidall
375|073|Poison Barb+
376|073|Belladonna's Bite
377|070|Shadow Slasher+
378|070|Spiritbinder
379|032|Shocking Slicer+
380|032|Shockstrike
381|032|Shockstrike+
382|031|Jyura Reaver+
383|031|Valtos Slough
384|031|Valtos Slough+
385|068|Great Anteka Blade
386|068|Great Anteka Blade+
387|068|King Anteka Blade
388|053|Illusory Frilled Slash+
389|053|Nightmare Frilled Slash
390|053|Nightmare Frilled Slash+
391|113|Bloom Snow Slash
392|113|Bloom Snow Slash+
393|113|Flicker Blizzard Slash
394|074|Douser Bardiche+
395|074|Wasserfallis
396|074|Wasserfallis+
397|118|Golm Cutter
398|118|Golm Cutter+
399|118|Titanfeller
400|069|Arzuros Strikequill+
401|069|Arzuros Telltail
402|051|Gale Scimitar+
403|051|Reaper Blade Boldus
404|062|Tormentor+
405|062|Darkness Within
406|062|Darkness Within+
407|103|Crab Cutter
408|103|Crab Cutter+
409|103|Daimyo Cutter
410|104|Ceanataur Cutter
411|104|Ceanataur Cutter+
412|104|Killer's Sickle
413|064|Jinxmonger
414|064|Jinxmonger+
416|064|Malicemonger
417|054|Sinister Shade Sword+
418|054|Tormented Shade Sword
419|112|Devil's Deal
420|085|Great Demon Halberd+
421|085|Evil Demon Halberd
422|056|Pandemonium
424|006|Bazel Jarre Blazer
425|115|Bazel Prozio Rooksearer
426|057|Torrential Hail
428|082|Daora's Raid+
429|082|Daora's Storm
430|083|Imperial Shimmer+
431|083|Imperial Flickerflame
432|084|Phantom Mirage+
433|084|Skulduggery
434|087|Red Flash
435|107|Stahlfakt
436|107|Stahlfakt+
437|107|Stahlurteil
438|108|La Justicière
439|108|Le Décalogue
440|119|Abyssal Flicker
441|105|Demonlord Halberd
442|067|Squawkscythe+
444|067|Screakscythe
445|088|Kamura's Inheritance+
447|088|Kamura's Legacy
448|122|Royal Order's Claymore
450|122|Royal Order's Claymore+
451|123|Antique Machina LS
452|121|Kaktus Himmel
453|102|Wyvern Blade "Pale"
454|101|Wyvern Blade "Luna"
456|106|Megrez's Asterism
463|091|Champion Long Sword II
464|091|Champion Long Sword III
465|091|Guardian Long Sword
466|114|Magma Disaster+
470|125|Lost Code: Kiri
471|127|Chaos/Loi
472|126|Stuffed Nargacuga
473|128|Reverent Elusarca
474|129|Ominous Spring
475|130|Silver Severer
"""),
    'Switch Axe': ('W_SlashAxe', 0x08600000, """
0|057|Elite Switch Axe I
1|057|Elite Switch Axe II
2|057|Czar Switch Axe
3|058|The Shredder I
4|058|The Shredder II
5|058|The Power Shredder
6|059|Ash Drache I
7|059|Ash Drache II
8|059|Fall Drache
9|017|Proto Iron Axe I
10|017|Proto Iron Axe II
11|017|Improved Steel Axe
12|060|General's Strongaxe I
13|060|General's Strongaxe II
14|060|Conqueress
15|019|Bone Axe I
16|019|Bone Axe II
17|019|Daidalos Axe
18|061|Power Gasher I
19|061|Power Gasher II
20|061|Maximal Gasher
21|050|Kamura Iron Axe I
22|050|Kamura Iron Axe II
23|050|Kamura Iron Axe III
24|050|Kamura Iron Axe IV
25|050|Kamura Iron Axe V
26|050|Kamura Ninja Axe
27|087|Rampage Slicer I
28|087|Rampage Slicer II
29|087|Rampage Slicer III
30|087|Rampage Slicer S
31|086|Origami Axe I
32|086|Origami Axe II
33|086|Petal Cloud
34|062|Grim Cat I
35|062|Grim Cat II
36|062|Grimmige Katze
37|063|Infernal Axe I
38|063|Infernal Axe II
39|063|Hellish Edge
40|085|Sleepy Shellslice I
41|085|Sleepy Shellslice II
42|085|Schale Batis
43|051|Axenosom I
44|051|Axenosom II
45|051|Axenosom III
46|051|Daybreak Silvaris
47|052|Wheel Axe I
48|052|Wheel Axe II
49|052|Axe of Wisdom
50|053|Sinister Axe I
51|053|Sinister Axe II
52|053|Sinister Shadowslice
53|054|Almudron Axe I
54|054|Almudron Axe II
55|054|Doom Bringer Axe
56|055|Azure Elder Axe I
57|055|Azure Elder Axe II
58|055|Abyssal Gale Axe
59|056|Thunderbolt Axe I
60|056|Abyssal Storm Axe
61|084|Redwing Switch Axe I
62|084|Reddnaught Dunat
63|064|Arzuros Axe I
64|064|Arzuros Axe II
65|064|Arzuros Revelax
66|065|Snowfall Axe I
67|065|Snowfall Axe II
68|065|Snowfall Axe III
69|065|Dewdrop Dream
70|066|Longear Axe I
71|066|Longear Axe II
72|066|Longear Axe III
73|066|Longear Weiss
74|067|Delex Sail I
75|067|Delex Sail II
76|067|Delex Cleaver
77|068|Ludroth Axe I
78|068|Ludroth Axe II
79|068|Splish Splax
80|069|Assault Axe I
81|069|Assault Axe II
82|069|Blitzkrieg
83|070|Khezu Axe I
84|070|Khezu Axe II
85|070|Khezu Cleaver
86|071|Venom Hatchet I
87|071|Venom Hatchet II
88|071|Mortal Serpent
89|072|Binding Roller I
90|072|Binding Roller II
91|072|Binding Roller III
92|072|Vermilingua
93|027|Limus Os I
94|027|Limus Os II
95|027|Luto Ascia
96|073|Dragonmaiden Axe I
97|073|Dragonmaiden Axe II
98|073|Gríðr's Landmaker
99|012|Amber Slash I
100|012|Amber Slash II
101|012|Amber Slash III
102|012|Amber Hoarfrost
103|005|Flammenbeil I
104|005|Flammenbeil II
105|005|Gnashing Flammenbeil
106|013|Hidden Axe I
107|013|Hidden Axe II
108|013|Night's Crescent
109|076|Fond Farewell I
110|076|Fond Farewell II
111|076|Parting Slice
112|077|Rath Flamesplitter I
113|077|Rath Flamesplitter II
114|077|Rath Flamesplitter III
115|077|Rath Blaze Splitter
116|078|Usurper's Downpour I
117|078|Usurper's Downpour II
118|078|Despot's Cloudburst
119|079|Rex Slasher I
120|079|Rex Slasher II
121|079|Rex Gnasher
122|003|Axe Semper Tyrannis I
123|003|Axe Semper Tyrannis II
124|003|Grand Chaos
125|080|Daora's Farasa I
126|080|Daora's Janah
127|001|Teostra's Arx I
128|001|Teostra's Castle
129|081|Waxglare Wand I
130|081|Balor's Mirage
131|082|Undying Axe I
132|082|Undying Axe II
133|082|Undying Light
134|037|Rookslayer Axe I
135|037|Rookslayer Axe II
136|037|Bazelrush Rookslayer
137|087|Rampage Slicer IV
138|087|Rampage Slicer V
139|088|Defender Switch Axe I
140|088|Champion Switch Axe
300|100|Kamura Warrior Battleaxe
301|100|Kamura Warrior Battleaxe+
302|100|Fine Kamura Battleaxe
303|115|Duke's Axe
304|115|Fracturing Falter
305|076|Parting Slice+
306|076|Leave-Taker
307|076|Leave-Taker+
308|110|Pure Switch Axe Mikado
309|077|Rath Blaze Splitter+
310|077|High Rubillion
311|052|Axe of Righteousness
312|052|Axe of Righteousness+
313|052|Battleaxe of Kings
314|112|Axe of Glory
315|112|Axe of Glory+
316|112|Axe of Virtue
317|067|Delex Cleaver+
318|067|Delex Hatchet
319|070|Khezu Cleaver+
320|070|Fullmark
321|070|Fullmark+
322|064|Arzuros Revelax+
323|064|Arzuros Jubilax
324|012|Amber Snapfrost
325|012|Amber Snapfrost+
326|012|Amber Permafrost
327|057|Czar Switch Axe II
328|057|Czar Switch Axe III
329|057|Valor Switch Axe
330|116|Frostmoon Eclipser
331|116|Frostmoon Eclipser+
332|116|Purnima Icechopper
333|027|Luto Ascia+
334|027|Valtos Claw
335|027|Valtos Claw+
336|073|Gríðr's Landmaker+
337|073|Gríðr's Landforger
338|073|Gríðr's Landforger+
339|119|Rosenacanta
340|119|Rosenacanta+
341|119|Rosenprion
342|060|Conqueress II
343|060|Conqueress III
344|060|Reconqueress
345|058|The Power Shredder+
346|058|The Lightning Shredder
347|058|The Lightning Shredder+
348|109|High Raijard
349|109|High Raijard+
350|109|Voltaic Load
351|059|Fall Drache+
352|059|Revived Drache
353|059|Revived Drache+
354|054|Night Bringer Axe
355|054|Night Bringer Axe+
356|054|Void Bringer Axe
357|113|Magma Switch
358|113|Volcanic Switch
359|051|Lunadawn Sirja
360|051|Lunadawn Sirja+
361|051|Dawnbreaker Simorgh
362|069|Battlebuster
363|069|Battlebuster+
364|069|Bastion Blitz
365|065|Dewdrop Dream+
367|065|Spirit Perplaxer
368|061|Maximal Gasher+
369|061|Powerhouse Gasher
370|061|Powerhouse Gasher+
371|108|Aksa Switch
372|108|Aksa Switch+
373|108|Baran Defiance
374|103|Scissor Axe
375|103|Scissor Axe+
376|103|Megatalon Shears
377|005|Gnashing Flammenbeil+
378|005|Lohenbeil
379|005|Lohenbeil+
380|079|Rex Gnasher+
381|079|Rex Thrasher
382|079|Rex Thrasher+
383|003|Grand Chaos+
384|003|Axe of Gaia
385|071|Mortal Serpent+
386|071|Thanatos Serpent
387|013|Crescent Moon
388|013|Crescent Moon+
389|013|Avidya Axe
390|072|Vermilingua+
391|072|Vermilion Bloodaxe
392|072|Vermilion Bloodaxe+
393|068|Splish Splax+
394|068|Ludroth Drencher
395|068|Ludroth Drencher+
396|117|Golm Axe
397|117|Golm Axe+
398|117|Great Gorgon Battleaxe
399|078|Despot's Cloudburst+
400|078|Oppressor's Torrent
401|066|Longear Weiss+
402|066|Splitear Weiss
403|053|Sinister Shadowslice+
404|053|Tormented Shadowslice
405|111|Vengeful Fellcleave
406|082|Undying Light+
407|082|Undying Purity
408|055|Skyfall
410|037|Bazelava Rookslayer
411|114|Bazelheart
412|056|Thunderclap
414|080|Daora's Janah+
415|080|Daora's Ajniha
416|001|Teostra's Castle+
417|001|Teostra's Hellebarde
418|081|Balor's Mirage+
419|081|Zariella's Phantasm
420|084|Wing of Sanctity
421|106|Eisenleib
422|106|Eisenleib+
423|106|Eisenherz
424|107|La Guillotine
425|107|La Conclusion
426|118|Abyssal Torrent
427|104|Demonlord Edge
428|086|Blossom Fall
430|086|Full Bloom Axe
431|062|Grimmige Katze+
433|062|Felyne Fatality
434|063|Hellish Edge+
435|063|Calamitous Axe
436|085|Schale Batis+
437|085|Dreamcrusher
438|121|Royal Order's Axe
440|121|Royal Order's Axe+
441|122|Antique Machina SA
442|120|Kaktusprion
443|102|Rathsplicer
444|101|Golden Crescent
446|105|Mizar's Asterism
453|003|Axe of Gaia+
454|088|Champion Switch Axe II
455|088|Champion Switch Axe III
456|088|Guardian Switch Axe
457|113|Magma Switch+
461|123|Lost Code: Labr
462|125|Frevel/Sursis
463|124|Stuffed Lunagaron
464|126|Wicked Niddoq
465|127|Cloudburst Axe
466|128|Silver Slasher
"""),
    'Gunlance': ('W_GunLance', 0x08700000, """
0|057|Striker's Gunlance I
1|057|Striker's Gunlance II
2|057|Imperial Guardlance
3|018|Iron Gunlance I
4|018|Iron Gunlance II
5|018|Eizenlitter
6|058|General's Arbalance I
7|058|General's Arbalance II
8|058|Admiral's Arbalance
9|021|Bone Gunlance I
10|021|Bone Gunlance II
11|021|Wyvern Bone Gunlance
12|059|Golem Gunlance I
13|059|Golem Gunlance II
14|059|Behemoth Gunlance
15|050|Kamura Gunlance I
16|050|Kamura Gunlance II
17|050|Kamura Gunlance III
18|050|Kamura Gunlance IV
19|050|Kamura Gunlance V
20|050|Kamura Ninja Gunlance
21|084|Rampage Gunlance I
22|084|Rampage Gunlance II
23|084|Rampage Gunlance III
24|084|Rampage Gunlance S
25|083|Canyne Cannon I
26|083|Canyne Cannon II
27|083|Howlitzer
28|060|Cornpopper I
29|060|Cornpopper II
30|060|Mighty Cornpopper
31|081|Sleepy Shellgun I
32|081|Sleepy Shellgun II
33|081|Soporific Shellgun
34|051|Aknosom Gunlance I
35|051|Aknosom Gunlance II
36|051|Aknosom Gunlance III
37|051|Dawnbreaker Gunlance
38|052|Sinister Gunlance I
39|052|Sinister Gunlance II
40|052|Sinister Shadowshot
41|053|Almudron Gunlance I
42|053|Almudron Gunlance II
43|053|Doombringer Gunlance
44|054|Rakna Gunlance I
45|054|Rakna Gunlance II
46|054|Araknalance
47|055|Azure Elder Gunlance I
48|055|Azure Elder Gunlance II
49|055|Abyssal Gale Gunlance
50|056|Thunderbolt Gunlance I
51|056|Abyssal Storm Gunlance
52|082|Redwing Gunlance I
53|082|Reddnaught Gunlance
54|061|Fiore Nulo I
55|061|Fiore Nulo II
56|061|Fiore Unu
57|063|Fiore Nulo White I
58|063|Fiore Nulo White II
59|063|Fiore Unu White
60|062|Fiore Nulo Green I
61|062|Fiore Nulo Green II
62|062|Fiore Unu Green
63|064|Fiore Nulo Black I
64|064|Fiore Nulo Black II
65|064|Fiore Unu Black
66|065|Baggi Gunlance I
67|065|Baggi Gunlance II
68|065|Baggi Gunlance III
69|065|Lullabyte Sleeplance
70|066|Lagomberator I
71|066|Lagomberator II
72|066|Lagomberator III
73|066|Lagomberatrix
74|080|Delex Harpoon I
75|080|Delex Harpoon II
76|080|Sand Blaster Gunlance
77|067|Ludroth Harpoon I
78|067|Ludroth Harpoon II
79|067|Ludroth Harpoon III
80|067|Ludroth Shellbreaker
81|068|Barroth Loader I
82|068|Barroth Loader II
83|068|Rugged Loader
84|069|Full Voltage I
85|069|Full Voltage II
86|069|High Volt Gunlance
87|070|Shattershot I
88|070|Shattershot II
89|070|Shatter God
90|071|Pukei Gunlance I
91|071|Pukei Gunlance II
92|071|Datura Gunlance
93|001|Princess Panoply I
94|001|Princess Panoply II
95|001|Ortlinde
96|013|Twinfang I
97|013|Twinfang II
98|013|Ambermarch
99|005|Kadachi Striker I
100|005|Kadachi Striker II
101|005|Mythic Kadachi Striker
102|032|Flaming Gunlance I
103|032|Flaming Gunlance II
104|032|Flaming Gunlance III
105|032|Barbarous Firelance
106|072|Hidden Gunlance I
107|072|Hidden Gunlance II
108|072|Fading Night
109|073|Ukiyo no Yamiwo I
110|073|Ukiyo no Yamiwo II
111|073|Mizumori
112|002|Red Rook I
113|002|Red Rook II
114|002|Crimson Rook
115|074|Usurper's Roar I
116|074|Usurper's Roar II
117|074|Despot's Phlogiston
118|014|Tiger Blast I
119|014|Tiger Blast II
120|014|Tigrex Gunlance
121|076|Diablos Gunlance I
122|076|Diablos Gunlance II
123|076|Diablos Cannon
124|003|Icesteel Gunlance I
125|003|Daora's Brigia
126|077|Venomous Cologne I
127|077|Venomous Attar
128|078|Demon Gunlance I
129|078|Demon Gunlance II
130|078|Great Demon Gunlance
131|040|Bazel Buster I
132|040|Bazel Buster II
133|040|Bazel Destroyer
134|084|Rampage Gunlance IV
135|084|Rampage Gunlance V
136|085|Defender Gunlance I
137|085|Champion Gunlance
300|100|Kamura Warrior Gunlance
301|100|Kamura Warrior Gunlance+
302|100|Fine Kamura Gunlance
303|115|Duke's Bayonet
304|115|Scorched Schleien
305|073|Mizumori+
306|073|Harae no Toboshi
307|073|Harae no Toboshi+
308|110|Pure Gunlance Izuna
309|001|Ortlinde+
310|001|Great Ortlinde
311|001|Great Ortlinde+
312|119|Rosenkanone
313|119|Rosenkanone+
314|119|Rosenherrlich
315|002|Crimson Rook+
316|002|Etince Chariot
317|080|Sand Blaster Gunlance+
318|080|Sandspear
319|074|Despot's Phlogiston+
320|074|Oppressor's Skyfall
321|013|Amberift
322|013|Amberift+
323|013|Amber Pike Ne'erthaw
324|057|Imperial Guardlance+
325|057|Praetorian Guardlance
326|057|Praetorian Guardlance+
327|116|Frostmoon Gunlance
328|116|Frostmoon Gunlance+
329|116|Pleniunio Frostpike
330|058|Admiral's Arbalance+
331|058|Imperial Swornlance
332|058|Imperial Swornlance+
333|109|Dark Chariot
334|109|Dark Chariot+
335|109|Zaram Chariot
336|071|Datura Gunlance+
337|071|Datura Grimbarb
338|071|Datura Grimbarb+
339|076|Diablos Cannon+
340|076|Diablos Horncannon
341|051|Dawnmoon Gunlance
342|051|Dawnmoon Gunlance+
343|051|Dawnmoon Detonator
344|053|Hellbringer Gunlance
345|053|Hellbringer Gunlance+
346|053|Endbringer Cataclysm
347|113|Flamebringer Gunlance
348|113|Burnbringer Eruption
349|069|High Volt Gunlance+
350|069|Giga Volt Gunlance
351|069|Giga Volt Gunlance+
352|070|Shatter God+
353|070|Shattercannon
354|070|Shattercannon+
355|065|Lullabyte Sleeplance+
357|065|Baggi Pike Cradle
358|005|Mythic Kadachi Striker+
359|005|Thundering Striker+
360|059|Behemoth Gunlance+
361|059|Gargantua Gunlance
362|059|Gargantua Gunlance+
363|108|Jaya Gunlance
364|108|Jaya Gunlance+
365|108|Riotous Gunlance
366|103|Scissor Gunlance
367|103|Scissor Gunlance+
368|103|Scissor Cannon
369|072|New Moon
370|072|New Moon+
371|072|Avidya Gunlance
372|032|Barbarous Firelance+
373|032|Pyre Pike
374|032|Pyre Pike+
375|068|Barroth Hellraiser
376|068|Barroth Hellraiser+
377|068|Barroth Reloader
378|014|Tigrex Gunlance+
379|014|Great Tigrex Gunlance
380|014|Great Tigrex Gunlance+
381|066|Lagomberatrix+
383|066|Lagombalanche
384|067|Ludroth Shellbreaker+
385|067|Droth Romeo
386|067|Droth Romeo+
387|117|Golm Benedictus
388|117|Golm Benedictus+
389|117|Resounding Gortrass
390|054|Araknablazer
391|054|Araknablazer+
392|054|Shadow Silencer
393|112|Scarlet Lamplance
394|112|Scarlet Lamplance+
395|112|Torci Da Lavater
396|064|Fiore Du Black
397|064|Fiore Tre Black
398|063|Fiore Du White
399|063|Fiore Tre White
400|062|Fiore Du Green
401|062|Fiore Tre Green
402|052|Sinister Shadowshot+
403|052|Mighty Soulsacker
404|111|Devil's Destiny
405|078|Great Demon Gunlance+
406|078|Dragon Gunlance
407|055|Skyrift Tempest
409|040|Bazel Kingtopper
410|114|Bazelpride
411|056|Skyrift Thunderstorm
413|003|Daora's Brigia+
414|003|Daora's Tempest
415|077|Venomous Attar+
416|077|Venomous Perfume
417|082|Crimson Furywing
418|106|Tyrannenarm
419|106|Tyrannenarm+
420|106|Hochmutsarm
421|107|L'Onde
422|107|La Forteresse
423|118|Abyssal Rockslide
424|104|Demonlord Gunlance
425|083|Howlitzer+
427|083|Roar of the Canyne
428|060|Mighty Cornpopper+
430|060|Crunchy Cornpopper
431|081|Soporific Shellgun+
432|081|Dreamsniper
433|121|Royal Order's Pledge
435|121|Royal Order's Pledge+
436|122|Antique Machina GL
437|120|Kaktus Herrlich
438|102|Silver Rook
439|101|Queen's Panoply
441|105|Alioth's Asterism
448|005|Thundering Striker
449|076|Diablos Horncannon+
452|085|Champion Gunlance II
453|085|Champion Gunlance III
454|085|Guardian Gunlance
467|113|Flamebringer Gunlance+
477|123|Lost Code: Nir
478|125|Mauer/Guerre
479|124|Stuffed Magnamalo
480|126|Vorpal Icefort
481|127|Ominous Monsoon
482|128|Silver Sploder
"""),
    'Dual Blades': ('W_DualBlades', 0x08800000, """
0|017|Matched Slicers I
1|017|Matched Slicers II
2|017|Dual Daggers
3|057|Hurricane I
4|057|Hurricane II
5|057|Cyclone
6|018|Dual Hatchets I
7|018|Dual Hatchets II
8|018|Dual Cleavers
9|003|Sworn Rapiers I
10|003|Sworn Rapiers II
11|003|Holy Sabers
12|058|Altair I
13|058|Altair II
14|058|Fortis Gran
15|019|Twin Chainsaws I
16|019|Twin Chainsaws II
17|019|Guillotines
18|059|Gelid Mind I
19|059|Gelid Mind II
20|059|Gelid Soul
21|021|Bone Hatchets I
22|021|Bone Hatchets II
23|021|Wild Hatchets
24|060|Talon Carvers I
25|060|Talon Carvers II
26|060|Talon Twins
27|061|Blazeblades I
28|061|Blazeblades II
29|061|Infernal Furies
30|050|Kamura Glintblades I
31|050|Kamura Glintblades II
32|050|Kamura Glintblades III
33|050|Kamura Glintblades IV
34|050|Kamura Glintblades V
35|050|Kamura Ninja Blades
36|083|Rampage Twinblades I
37|083|Rampage Twinblades II
38|083|Rampage Twinblades III
39|083|Rampage Twinblades S
40|843|Stealth Dango I
41|843|Stealth Dango II
42|843|Perfected Dango
43|064|Felyne Claws I
44|064|Felyne Claws II
45|064|Raging Claws
46|082|Rainy Jelly I
47|082|Rainy Jelly II
48|082|Rain of Gore
49|063|Qornu Waga I
50|063|Qornu Waga II
51|063|Ro Waga
52|051|Schirmscorn I
53|051|Schirmscorn II
54|051|Daybreak Daggers
55|052|Frilled Claw I
56|052|Frilled Claw II
57|052|Illusory Frilled Claw
58|053|Sinister Blades I
59|053|Sinister Blades II
60|053|Sinister Famineblades
61|054|Mud Ripper I
62|054|Mud Ripper II
63|054|Mud Twister
64|055|Azure Elder Blades I
65|055|Azure Elder Blades II
66|055|Abyssal Gale Blades
67|056|Thunderbolt Blades I
68|056|Abyssal Storm Blades
69|081|Redwing Blades I
70|081|Reddnaught Dragon Wing
71|065|Cerulean Axes I
72|065|Cerulean Axes II
73|065|Ashigara Axes
74|066|Snow Slicers I
75|066|Snow Slicers II
76|066|Snow Sisters
77|067|Desperado I
78|067|Desperado II
79|067|The Kid
80|028|Kulu's Peck I
81|028|Kulu's Peck II
82|028|Kulu's Lasher
83|068|Ludroth Pair I
84|068|Ludroth Pair II
85|068|Double Droth
86|069|Khezu Daggers I
87|069|Khezu Daggers II
88|069|Khezu Skards
89|029|Jyura Duo I
90|029|Jyura Duo II
91|029|Jyura Pulverizers
92|012|Blizzarioths I
93|012|Blizzarioths II
94|012|Mountain Blizzarioths
95|030|Kadachi Twinblades I
96|030|Kadachi Twinblades II
97|030|Shockblades
98|031|Flammenschild I
99|031|Flammenschild II
100|031|Gnashing Flammenschild
101|072|Hidden Gemini I
102|072|Hidden Gemini II
103|072|Night Wings
104|073|Morning Dawn I
105|073|Morning Dawn II
106|073|Evening Dusk
107|070|Twin Flames I
108|070|Twin Flames II
109|070|Wyvern Lovers
110|074|Usurper's Fulgur I
111|074|Usurper's Fulgur II
112|074|Despot's Blitz
113|075|Rex Slicers I
114|075|Rex Slicers II
115|075|Tigrex Claws
116|076|Diablos Bashers I
117|076|Diablos Bashers II
118|076|Diablos Mashers
119|077|Icesteel Fang I
120|077|Daora's Hook
121|001|Twin Nails I
122|001|Fire and Ice
123|078|Rouge Flames I
124|078|Dual Chameleos
125|079|Suzuka Takamaru I
126|079|Suzuka Takamaru II
127|079|Suzuka Otakemaru
128|006|Rookslayer Handaxes I
129|006|Rookslayer Handaxes II
130|006|Bazelhawk Rookslayer
131|083|Rampage Twinblades IV
132|083|Rampage Twinblades V
133|085|Defender Dual Blades I
134|085|Champion Dual Blades
300|100|Kamura Warrior Blades
301|100|Kamura Warrior Blades+
302|100|Fine Kamura Blades
303|115|Duke's Cleavers
304|115|Bloody Nails Wunde
305|054|Mud Slicers
306|054|Mud Slicers+
307|054|Mud Shredders
308|113|Magma Slicers
309|113|Magma Shredders
310|074|Despot's Blitz+
311|074|Oppressor's Miracle
312|012|Flame Blizzard
313|012|Flame Blizzard+
314|012|Raider's Icecarvers
315|067|The Kid+
316|067|The Legend
317|069|Khezu Skards+
318|069|Blood Wind Skards
319|069|Blood Wind Skards+
320|057|Cyclone+
321|057|Supercell
322|057|Supercell+
323|075|Tigrex Claws+
324|075|Huge Tigrex Claws
325|075|Huge Tigrex Claws+
326|073|Evening Dusk+
327|073|Dark Aurora
328|073|Dark Aurora+
329|110|Pure Blades Tsurugi
330|051|Dawnmoon Daggers
331|051|Dawnmoon Daggers+
332|051|Dawnmoon Disrupters
333|028|Kulu's Lasher+
334|028|Kulu Katolos Blades
335|059|Gelid Spirit
336|059|Gelid Spirit+
337|059|Gelid Heart
338|116|Frostmoon Bloodclaws
339|116|Frostmoon Bloodclaws+
340|116|Fengul Frostclaws
341|072|Midnight Wings
342|072|Midnight Wings+
343|072|Avidya Blades
344|019|Guillotines+
345|019|Final Chainsaws
346|019|Final Chainsaws+
350|109|Twin Wyvern Beams
351|109|Twin Wyvern Beams+
352|109|Twin Wyvern Bolts
353|065|Ashigara Axes+
354|065|Oeyama Axes
355|031|Gnashing Flammenschild+
356|031|Lohenschild
357|031|Lohenschild+
358|060|Talon Twins+
359|060|Talon Gemini
360|060|Talon Gemini+
361|108|Zakun Twins
362|108|Zakun Twins+
363|108|Terrible Twins
364|102|Crab Horns
365|102|Crab Horns+
366|102|Lobster Piercers
367|103|Bladed Edges
368|103|Bladed Edges+
369|103|Limb Cutter
370|070|Wyvern Lovers+
371|070|Flaming Wyvern Lovers
372|119|Rosenzahn
373|119|Rosenzahn+
374|119|Rosenehrgeiz
375|076|Diablos Mashers+
376|076|Diablos Smashers
377|076|Diablos Smashers+
378|029|Jyura Pulverizers+
379|029|Valtos Os
380|029|Valtos Os+
381|030|Shockblades+
382|030|Thunderblades
383|030|Thunderblades+
384|068|Double Droth+
385|068|Double Droth Flood
386|068|Double Droth Flood+
387|117|Golm Golm
388|117|Golm Golm+
389|117|Binary Gorgoth
390|052|Illusory Frilled Claw+
391|052|Nightmare Frilled Claws
392|052|Nightmare Frilled Claws+
393|112|Bloom Snow Claws
394|112|Bloom Snow Claws+
395|112|Glistening Snow Claws
396|061|Infernal Fury Nova
397|061|Infernal Fury Nova+
398|061|Unquenchable Flames
399|066|Snow Sisters+
400|066|Snow Ravines
401|053|Sinister Famineblades+
402|053|Mighty Soulchoker
403|111|Blue Blaze Blades
404|079|Suzuka Otakemaru+
405|079|Suzuka Akurou
406|055|Twin Twisters
408|006|Bazelhound Rookslayer
409|114|Bazel Bombers
410|056|Double Discharge
412|077|Daora's Hook+
413|077|Daora's Ventus
414|001|Fire and Ice+
415|001|Blizzard and Blaze
416|078|Dual Chameleos+
417|078|Chameleos Blades
418|081|Crimson Twinwing
419|106|Fledderklauen
420|106|Fledderklauen+
421|106|Aasklauen
422|107|Les Apôtres
423|107|Le Shangri-La
424|118|Abyssal Celestials
425|104|Demonlord Fist
426|064|Raging Claws+
427|064|Raging Paws
428|082|Rain of Gore+
429|082|Elegant Jelly
430|063|Ro Waga+
432|063|Gila Ro Waga
433|003|Holy Sabers+
436|003|Sacred Espadas
437|058|Fortis Gran+
438|058|Auditore Glam
439|843|Stealth Dango Supreme
440|843|Stealth Dango Ultimate
441|121|Royal Order's Rapiers
443|121|Royal Order's Rapiers+
444|122|Antique Machina DB
445|120|Kaktus Ehrgeiz
446|101|Wyvern Strife
448|105|Alkaid's Asterism
467|123|Elder Fugen's Blades
468|123|Elder Fugen's Blades+
469|085|Champion Dual Blades II
470|085|Champion Dual Blades III
471|085|Guardian Dual Blades
472|113|Magma Slicers+
476|124|Lost Code: Rah
477|126|Shangri-La/Hades
478|125|Stuffed Goss Harag
479|127|Untouched Hel
480|128|Stormwind Fans
481|129|Silver Slicers
"""),
    'Hunting Horn': ('W_Horn', 0x08900000, """
0|018|Metal Bagpipe I
1|018|Great Bagpipe
2|058|Iron Horn I
3|058|Wind Horn
4|059|Heavy Bagpipe I
5|059|Fortissimo
6|020|Bone Horn I
7|020|Bone Horn II
8|020|Hardened Bone Horn
9|060|Hunter's Horn I
10|060|Native's Horn
11|050|Kamura Chorus I
12|050|Kamura Chorus II
13|050|Kamura Chorus III
14|050|Kamura Chorus IV
15|050|Kamura Chorus V
16|050|Kamura Ninja Horn
17|087|Rampage Agitato I
18|087|Rampage Agitato II
19|087|Rampage Agitato III
20|087|Rampage Agitato S
21|086|Grass Flute I
22|086|Grass Flute II
23|086|Bombadgy's Cry
24|061|Magia Charm I
25|061|Magia Charm II
26|061|Magia Charm III
27|061|Magia Charmbell
28|062|Poison Fungasax I
29|062|Poison Fungasax II
30|062|Toxic Fungasax
31|063|Cornupion I
32|063|Cornupion II
33|063|Webbed Cornupion
34|051|Wind Thief Horn I
35|051|Wind Thief Horn II
36|051|Gale Horn
37|052|Frog Flute I
38|052|Frog Flute II
39|052|Amphibia Allargando
40|053|Frilled Flute I
41|053|Frilled Flute II
42|053|Illusory Flute
43|054|Sinister Strum I
44|054|Sinister Strum II
45|054|Sinister Shadestrum
46|055|Sublime Bell I
47|055|Sublime Bell II
48|055|Araknahorn
49|056|Azure Elder Horn I
50|056|Azure Elder Horn II
51|056|Abyssal Gale Horn
52|057|Thunderbolt Horn I
53|057|Abyssal Storm Horn
54|084|Redwing Flute I
55|084|Reddnaught Ritmico
56|064|Bull Grunt I
57|064|Bull Grunt II
58|064|Wild Grunt
59|065|Vicello Nulo I
60|065|Vicello Nulo II
61|065|Vicello Unu
62|067|Vicello Nulo White I
63|067|Vicello Nulo White II
64|067|Vicello Unu White
65|066|Vicello Nulo Green I
66|066|Vicello Nulo Green II
67|066|Vicello Unu Green
68|068|Vicello Nulo Black I
69|068|Vicello Nulo Black II
70|068|Vicello Uno Black
71|069|Zurogong Primo I
72|069|Zurogong Primo II
73|069|Zurogong Secundo
74|029|Kulu Mosso I
75|029|Kulu Mosso II
76|029|Kulu Grosso
77|070|Droth Drone I
78|070|Droth Drone II
79|070|Droth Roar
80|071|Sandpipe I
81|071|Sandpipe II
82|071|Sandcrier
83|072|Khezu Horn I
84|072|Khezu Horn II
85|072|Khezu Flute
86|031|Pukei Bagpipe I
87|031|Pukei Bagpipe II
88|031|Datura Lurr
89|073|Basarios Rock I
90|073|Basarios Rock Mk.II
91|073|Gigant Rock
92|002|Valkyrie Chordmaker I
93|002|Valkyrie Chordmaker II
94|002|Queen Chordmaker
95|074|Bariguiro I
96|074|Bariguiro II
97|074|Algiguiro
98|034|Flammenkornett I
99|034|Flammenkornett II
100|034|Forte Flammenkornett
101|013|Hidden Harmonic I
102|013|Hidden Harmonic II
103|013|Cry in the Night
104|076|Poetic Bell I
105|076|Poetic Bell II
106|076|Summoning Bell
107|077|Flame Feroce I
108|077|Flame Feroce II
109|077|Rathalos Feroce
110|078|Usurper's Growl I
111|078|Usurper's Growl II
112|078|Despot's Thunderclap
113|012|Striped Dragonga I
114|012|Striped Dragonga II
115|012|Tigrex Horn
116|080|Duo Horn I
117|080|Duo Horn II
118|080|Duo Risoluto
119|081|Daora's Taus I
120|081|Daora's Baphophone
121|001|Teostra's Tiple I
122|001|Teostra's Orphée
123|082|Blessed Ocarina I
124|082|Cursed Ocarina
125|083|Denden Daiko I
126|083|Denden Daiko II
127|083|Denden Doomsounder
128|006|Rookslayer Drum I
129|006|Rookslayer Drum II
130|006|Bazelreid Rookslayer
131|087|Rampage Agitato IV
132|087|Rampage Agitato V
133|088|Defender Horn I
134|088|Champion Horn
300|100|Kamura Warrior Flute
301|100|Kamura Warrior Flute+
302|100|Fine Kamura Flute
303|114|Duke's Grail
304|114|Magician's Allure
305|076|Summoning Bell+
306|076|Sublime Bell
307|076|Sublime Bell+
308|109|Pure Bell Inari
309|055|Araknatootle
310|055|Araknatootle+
311|055|Doomed Bell
312|112|Garance Toll
313|112|Garance Toll+
314|112|Kampa Da Lavater
315|073|Gigant Rock+
316|073|Titan's Rock
317|078|Despot's Thunderclap+
318|078|Oppressor's Boon
319|069|Zurogong Secundo+
320|069|Zurogong Tertio
321|012|Tigrex Horn+
322|012|Tigrex Roar
323|012|Tigrex Roar+
324|074|Guiro Frula
325|074|Guiro Frula+
326|074|Frigiguiro
327|053|Illusory Flute+
328|053|Nightmare Flute
329|053|Nightmare Flute+
330|111|Bloom Snow Flute
331|111|Bloom Snow Flute+
332|111|Flicker Blizzard Flute
333|059|Fortissimo+
334|059|Rinforzato
335|059|Rinforzato+
336|108|Grundner Flap
337|108|Grundner Flap+
338|108|Grünlicht Flap
339|115|Frostmoon Wailer
340|115|Frostmoon Wailer+
341|115|Harmonic Resonance
342|013|Horn of Deprivation
343|013|Horn of Deprivation+
344|013|Avidya Harmonic
345|031|Datura Lurr+
346|031|Datura Accelerando
347|031|Datura Accelerando+
348|034|Forte Flammenkornett+
349|034|Horn of the Indomitable
350|034|Horn of the Indomitable+
351|002|Queen Chordmaker+
352|002|Queen's Harmonium
353|002|Queen's Harmonium+
354|118|Rosengitarre
355|118|Rosengitarre+
356|118|Rosenseele
357|071|Sandcrier+
358|071|Sandscreecher
359|071|Sandscreecher+
360|052|Amphibia Allargando+
361|052|Amphibia Larghetto
362|052|Amphibia Larghetto+
363|051|Gale Horn+
364|051|Great Gale Horn
365|070|Droth Roar+
366|070|Echoing Droth Roar
367|070|Echoing Droth Roar+
368|116|Golm Drum
369|116|Golm Drum+
370|116|Seismic Pauken
374|102|Shell Castanet
375|102|Shell Castanet+
376|102|Colored Castanet
377|107|Vadya Muse
378|107|Vadya Muse+
379|107|Allysyl Muse
380|080|Duo Risoluto+
381|080|Horned Tyrant's Horn
382|080|Horned Tyrant's Horn+
383|064|Feral Grunt
384|064|Feral Grunt+
385|064|Barbarian Grunt
386|122|Sonic Glass
387|122|Sonic Glass+
388|122|Glass Queen
389|077|Rathalos Feroce+
390|077|Ophelia's Grace
391|029|Kulu Grosso+
392|029|Kulu Katolos Mosso
393|072|Khezu Flute+
394|072|Khezu Keen
395|072|Khezu Keen+
396|068|Vicello Du Black
397|068|Vicello Tre Black
398|068|Vicello Kvar Black
399|066|Vicello Du Green
400|066|Vicello Tre Green
401|067|Vicello Du White
402|067|Vicello Tre White
403|054|Sinister Shadestrum+
404|054|Mighty Souleraser
405|110|Devil's Lute
406|083|Denden Doomsounder+
407|083|Denden Delugesong
408|056|Skytremor Typhoon
410|006|Baselsium Rookslayer
411|113|Bazel Valdi Rooksearer
412|057|Skytremor Rumble
414|081|Daora's Baphophone+
415|081|Daora's Diabassoon
416|001|Teostra's Orphée+
417|001|Teostra's Musica
418|082|Cursed Ocarina+
419|082|Genie's Ocarina
420|084|Crimson Clearwing
421|105|Kummerklang
422|105|Kummerklang+
423|105|Trauerklang
424|106|La Sépulture
425|106|Le Grégorien
426|117|Abyssal Hollow
427|103|Demonlord Djembe
428|062|Toxic Fungasax+
430|062|Mycotoxic Fungasax
431|061|Magia Charmbell+
433|061|Bell of Laertes
434|063|Hamlet's Horn
436|063|Gossamer Cornupion
437|086|Bombadgy's Cry+
438|086|Raccoon Dog Auldhorn
439|120|Royal Order's Horn
441|120|Royal Order's Horn+
442|121|Antique Machina HH
443|119|Kaktus Seele
444|101|Gold Chordmaker
446|104|Namalsadirah's Asterism
453|088|Champion Horn II
454|088|Champion Horn III
455|088|Guardian Horn
459|123|Lost Code: Alos
460|125|Grimm/Joie
461|124|Stuffed Tigrex
462|126|Sonorous Eisfyl
463|127|Autumn Lute
464|128|Silver Smasher
"""),
    'Insect Glaive': ('W_InsectGlaive', 0x08A00000, """
0|058|Iron Bayonet I
1|058|Iron Bayonet II
2|058|Hiten Blade
3|018|Iron Blade I
4|018|Iron Blade II
5|018|Steel Blade
6|020|Bone Staff I
7|020|Bone Staff II
8|020|Aerial Glaive
9|059|Sturdy Glaive I
10|059|Sturdy Glaive II
11|059|Sturdy Glaive Redux
12|060|Sky-High Glaive I
13|060|Sky-High Glaive II
14|060|Highest of Glaives
15|050|Kamura Glaive I
16|050|Kamura Glaive II
17|050|Kamura Glaive III
18|050|Kamura Glaive IV
19|050|Kamura Glaive V
20|050|Kamura Ninja Glaive
21|083|Rampage Glaive I
22|083|Rampage Glaive II
23|083|Rampage Glaive III
24|083|Rampage Glaive S
25|082|Brush Glaive I
26|082|Brush Glaive II
27|082|Watercolor Glaive
28|061|Magia Pitareen I
29|061|Magia Pitareen II
30|061|Magia Pitareen III
31|061|Magia Crescent
32|063|Deathport Staff I
33|063|Deathport Staff II
34|063|Garamorse
35|051|Aknosom Pike I
36|051|Aknosom Pike II
37|051|Daybreak Glaive
38|052|Leaping Glaive I
39|052|Leaping Glaive II
40|052|Leapfrog
41|053|Frilled Jab I
42|053|Frilled Jab II
43|053|Illusory Frilled Jab
44|054|Sinister Staff I
45|054|Sinister Staff II
46|054|Sinister Shadowstaff
47|055|Gossglaive I
48|055|Gossglaive II
49|055|Abominable Glaive
50|056|Azure Elder Glaive I
51|056|Azure Elder Glaive II
52|056|Abyssal Gale Glaive
53|057|Thunderbolt Glaive I
54|057|Abyssal Storm Glaive
55|080|Redwing Glaive I
56|080|Reddnaught Shuma
57|064|Rielle Nulo I
58|064|Rielle Nulo II
59|064|Rielle Unu
60|067|Rielle Nulo Red I
61|067|Rielle Nulo Red II
62|067|Rielle Vermiglio
63|066|Rielle Nulo White I
64|066|Rielle Nulo White II
65|066|Rielle Unu White
66|065|Rielle Nulo Green I
67|065|Rielle Nulo Green II
68|065|Rielle Unu Green
69|068|Rielle Nulo Black I
70|068|Rielle Nulo Black II
71|068|Rielle Nerissimo
72|069|Hortadent I
73|069|Hortadent II
74|069|Hortadent Brada
75|070|Lagombaglaive I
76|070|Lagombaglaive II
77|070|Lagombavarice
78|027|Kulu Glaive I
79|027|Kulu Glaive II
80|027|Kulu Pike
81|071|Royal Bloom I
82|071|Royal Bloom II
83|071|Bloom Royale
84|072|Bolt Chamber I
85|072|Bolt Chamber II
86|072|Full Bolt Chamber
87|028|Pukei Rod I
88|028|Pukei Rod II
89|028|Datura Pike
90|073|Princess Regalia I
91|073|Princess Regalia II
92|073|Queen Regalia
93|012|Amber Piton I
94|012|Amber Piton II
95|012|Fenrir Storm
96|029|Kadachi Glaive I
97|029|Kadachi Glaive II
98|029|Shocking Pike
99|005|Flammenkaefer I
100|005|Flammenkaefer II
101|005|Gnashing Flammenkaefer
102|074|Hidden Scythe I
103|074|Hidden Scythe II
104|074|Evening Calm
105|075|Fox Halberd I
106|075|Fox Halberd II
107|075|Curved Naganagi
108|003|Rathmaul I
109|003|Rathmaul II
110|003|Firedance Rathmaul
111|081|Royal Bolt Scepter I
112|081|Royal Bolt Scepter II
113|081|Despot's Twinbolt
114|076|Tigrex Kaina I
115|076|Tigrex Kaina II
116|076|Tigerclaw Glaive
117|077|Diablos Rod I
118|077|Diablos Rod II
119|077|Tyrant Rod
120|002|Daora's Entom I
121|002|Daora's Tethidine
122|078|Caster's Rod I
123|078|Hazy Caster
124|079|Metal Mauler I
125|079|Metal Mauler II
126|079|Metalmangler
127|083|Rampage Glaive IV
128|083|Rampage Glaive V
129|084|Defender Glaive I
130|084|Champion Glaive
300|100|Kamura Warrior Glaive
301|100|Kamura Warrior Glaive+
302|100|Fine Kamura Glaive
303|112|Duke's Scepter
304|112|Whiplash Stock
305|074|Twilight Repose
306|074|Twilight Repose+
307|074|Avidya Scythe
308|075|Curved Naganagi+
309|075|Eventide Kazanagi
310|075|Eventide Kazanagi+
311|109|Pure Naginata Sumi
312|053|Illusory Frilled Jab+
313|053|Nightmare Frilled Jab
314|053|Nightmare Frilled Jab+
315|111|Bloom Snow Jab
316|111|Bloom Snow Jab+
317|111|Flicker Blizzard Jab
318|076|Tigerclaw Glaive+
319|076|Great Tigerclaw Glaive
320|076|Great Tigerclaw Glaive+
321|052|Leapfrog+
322|052|True Leapfrog
323|052|True Leapfrog+
324|058|Dauntless Bayonet
325|058|Dauntless Bayonet+
326|058|Steel Dauntless Bayonet
327|113|Frostmoon Razorglaive
328|113|Frostmoon Razorglaive+
329|113|Iceberg Tunggul
330|108|Thunder Tusk
331|108|Thunder Tusk+
332|108|Thunder Dragon
333|003|Firedance Rathmaul+
334|003|Fiery Rath
335|072|Full Bolt Chamber+
336|072|Surge Chamber
337|072|Surge Chamber+
338|073|Queen Regalia+
339|073|Empress Regalia
340|073|Empress Regalia+
341|116|Rosenstange
342|116|Rosenstange+
343|116|Rosenspringen
344|051|Dawnmoon Glaive
345|051|Dawnmoon Beambreak
346|027|Kulu Pike+
347|027|Kulu Katolos Pike
348|029|Shocking Pike+
349|029|Thundering Pike
350|029|Thundering Pike+
351|070|Lagombavarice+
352|070|Sawtooth
353|059|Sturdy Glaive Redux+
354|059|Stalwart Glaive
355|059|Stalwart Glaive+
356|107|Altair
357|107|Altair+
358|107|Alteal
359|102|Shell Intoner
360|102|Shell Intoner+
361|102|Crab Intoner
362|060|Highest of Glaives+
363|060|Stratosphere Glaive
364|060|Stratosphere Glaive+
365|077|Tyrant Rod+
366|077|Horned Tyrant
367|005|Gnashing Flammenkaefer+
368|005|Lohenspire
369|005|Lohenspire+
370|055|Abominable Snowpole
371|055|Abominable Snowpole+
372|055|Far North Pole
373|028|Datura Pike+
374|028|Datura Plume
375|028|Datura Plume+
376|012|Midgard Storm
377|012|Midgard Storm+
378|012|Pure Helltone
379|071|Bloom Royale+
380|071|Waterspout Bloom
381|071|Waterspout Bloom+
382|114|Golm Glaive
383|114|Golm Glaive+
384|114|Maneater
385|081|Despot's Twinbolt+
386|081|Despot's Twindart
387|069|Hortadent Brada+
388|069|Altaroth Trident
389|069|Altaroth Trident+
390|067|Rielle Du Red
391|067|Rielle Tre Red
392|067|Rielle Kvar Red
393|068|Rielle Du Black
394|068|Rielle Tre Black
395|066|Rielle Du White
396|066|Rielle Tre White
397|065|Rielle Du Green
398|065|Rielle Tre Green
399|054|Sinister Shadowstaff+
400|054|Mighty Soulromancer
401|110|Devil's Halberd
402|079|Metalmangler+
403|079|Metal Mutilator
404|056|Skysoar Hurricane
406|057|Skysoar Flash
408|002|Daora's Tethidine+
409|002|Daora's Samudra
410|078|Hazy Caster+
411|078|Veil Caster
412|080|Crimson Springwing
413|105|Leumundslist
414|105|Leumundslist+
415|105|Leumundsbruch
416|106|Le Traqueur
417|106|Le Miracle
418|115|Abyssal Insectoid
419|103|Demonlord Cudgel
420|063|Garamorse+
422|063|Darkmorse
423|061|Magia Crescent+
425|061|Staff of Laertes
426|082|New World Brush Glaive
428|082|Poet's Brush Glaive
429|118|Royal Order's Glaive
431|118|Royal Order's Glaive+
432|119|Antique Machina IG
433|117|Kaktusspringen
434|101|Heaven's Rath Glaive
436|104|Aoul al Sadirah's Asterism
445|051|Dawnmoon Glaive+
446|077|Horned Tyrant+
447|084|Champion Glaive II
448|084|Champion Glaive III
449|084|Guardian Glaive
454|120|Lost Code: Telth
455|122|Wehmut/Merveille
456|121|Stuffed Rakna-Kadaki
457|123|Wise Fylos
458|124|Stratus Arc
459|125|Silver Spear
"""),
    'Charge Blade': ('W_ChargeAxe', 0x08B00000, """
0|018|Hyperguard I
1|018|Hyperguard II
2|018|Regas Hyper
3|059|Elite Blade I
4|059|Elite Blade II
5|059|Kaiser Blade
6|060|K. Captain's Blade I
7|060|K. Captain's Blade II
8|060|Die Walküre
9|021|Bone Blade I
10|021|Bone Blade II
11|021|Bonesilt Veil
12|020|Bone Strongarm I
13|020|Bone Strongarm II
14|020|Hard Bone Strongarm
15|061|Poisonous Veil I
16|061|Poisonous Veil II
17|061|Infected Veil
18|062|Dragon Veil I
19|062|Dragon Veil II
20|062|Dragonsong
21|050|Kamura C. Blade I
22|050|Kamura C. Blade II
23|050|Kamura C. Blade III
24|050|Kamura C. Blade IV
25|050|Kamura C. Blade V
26|050|Kamura Ninja C. Blade
27|081|Rampage C. Blade I
28|081|Rampage C. Blade II
29|081|Rampage C. Blade III
30|081|Rampage C. Blade S
31|080|Ricebane I
32|080|Ricebane II
33|080|Pounder of Rice
34|065|Cuddly Cat I
35|065|Cuddly Cat II
36|065|Felyne Fancy
37|064|Mandible Blade I
38|064|Mandible Blade II
39|064|Maxilla Edge
40|063|Vaik Veil I
41|063|Vaik Veil II
42|063|Shieldraad
43|051|Wind Thief Sickle I
44|051|Wind Thief Sickle II
45|051|Gale Sickle
46|052|Shovedown Blade I
47|052|Shovedown Blade II
48|052|Spinning Takedown
49|053|Bellowing Blow I
50|053|Bellowing Blow II
51|053|Illusory Frilled Wail
52|054|Sinister Slasher I
53|054|Sinister Slasher II
54|054|Sinister Shade Axe
55|055|Surprise Axe I
56|055|Surprise Axe II
57|055|Stunning Axe
58|056|Biting Edge I
59|056|Biting Edge II
60|056|Araknablade
61|057|Azure Elder Blade I
62|057|Azure Elder Blade II
63|057|Abyssal Gale Ward
64|058|Thunderbolt Sawtooth I
65|058|Abyssal Storm Ward
66|077|Redwing Edge I
67|077|Skaltecore
68|066|Barroth Anchor I
69|066|Barroth Anchor II
70|066|Rugged Anchor
71|067|Rough Roller I
72|067|Rough Roller II
73|067|Rotaxion
74|028|Jyura Silt I
75|028|Jyura Silt II
76|028|Clutch of the Deep
77|068|Giga Grips I
78|068|Giga Grips II
79|068|Giga Grips III
80|068|Titan's Vise
81|002|Dear Lutemis I
82|002|Dear Lutemis II
83|002|Dear Lutemia
84|012|Weissritter I
85|012|Weissritter II
86|012|Weissritter III
87|012|Pavadira
88|029|Kadachi Slasher I
89|029|Kadachi Slasher II
90|029|Kadachi Otenta
91|070|Hidden Arsenal I
92|070|Hidden Arsenal II
93|070|Scream in the Night
94|071|Mizuniya Drill I
95|071|Mizuniya Drill II
96|071|Final Fieldblade
97|003|Axelion Blade I
98|003|Axelion Blade II
99|003|Bardichion Blade
100|079|Usurper's Lightning I
101|079|Usurper's Lightning II
102|079|Despot's Thundergale
103|072|Tigrex Divide I
104|072|Tigrex Divide II
105|072|Tigrex Blade
106|073|Diablos Strongarm I
107|073|Diablos Strongarm II
108|073|Cera Strongarm
109|001|Daora's Casca I
110|001|Daora's Thwartoise
111|074|Teostra's Striker I
112|074|Teostra's Nova
113|075|Arcane Draw I
114|075|Etherward
115|076|Undying Blade I
116|076|Undying Blade II
117|076|Ikaji Immortal
118|081|Rampage C. Blade IV
119|081|Rampage C. Blade V
120|082|Defender Charge Blade I
121|082|Champion Charge Blade
300|100|Kamura Warrior C. Blade
301|100|Kamura Warrior C. Blade+
302|100|Kamura Fine C. Blade
303|114|Duke's Shield
304|114|Bloodeagle Adler
305|002|Dear Lutemia+
306|002|Dear Lutemineva
307|002|Dear Lutemineva+
308|118|Rosenrupe
309|118|Rosenrupe+
310|118|Rosenemolgia
311|012|Frostrail
312|012|Frostrail+
313|012|Dreadfeller
314|079|Despot's Thundergale+
315|079|Oppressor's Thunderclap
316|052|Spinning Takedown+
317|052|Whirling Takedown
318|052|Whirling Takedown+
319|068|Titan's Vise+
321|068|Goliath Arms
322|055|Striking Axe
323|055|Striking Axe+
324|055|Shocking Axe
325|059|Kaiser Blade+
326|059|Kaiser Kommandant
327|059|Kaiser Kommandant+
328|115|Frostmoon Icecutioner
329|115|Frostmoon Icecutioner+
330|115|Gluttonous Glacier
331|060|Die Walküre+
332|060|Tristan and Isolde
333|060|Tristan and Isolde+
334|109|Vajraklex Blade
335|109|Amagarex Blade
336|109|Amagarex Blade+
337|056|Araknasmasher
338|056|Araknasmasher+
339|056|Crawling Crusher
340|113|Roujatov Gate
341|113|Roujatov Gate+
342|113|Ent Da Lavater
343|072|Tigrex Blade+
344|072|Huge Tigrex Blade
345|072|Huge Tigrex Blade+
346|071|Final Fieldblade+
347|071|Divine Fieldblade
348|071|Divine Fieldblade+
349|110|Pure Axe Omonshiro
350|029|Kadachi Otenta+
351|029|Thunderclap Otenta
352|029|Thunderclap Otenta+
353|051|Gale Sickle+
354|051|Reaper Axe Helliot
355|070|Howl in the Rain
356|070|Howl in the Rain+
357|070|Avidya Charger
358|021|Bonesilt Veil+
359|021|Bonebreaker Veil
360|021|Bonebreaker Veil+
361|108|Aslat Charger
362|108|Aslat Charger+
363|108|Rebellious Charger
364|103|Guardian Blade
365|103|Guardian Blade+
366|103|Nadegiri
367|028|Clutch of the Deep+
368|028|Valtos Bow
369|028|Valtos Bow+
370|003|Bardichion Blade+
371|003|Flamlion Blade
372|053|Illusory Frilled Wail+
373|053|Nightmare Frilled Wail
374|053|Nightmare Frilled Wail+
375|112|Bloom Snow Wail
376|112|Bloom Snow Wail+
377|112|Flicker Blizzard Wail
378|061|Infected Veil+
379|061|Malefico Veil
380|061|Malefico Veil+
381|062|Dragonsong+
382|062|Draquila Reaver
383|062|Draquila Reaver+
384|066|Barroth Guardian
385|066|Barroth Reanchor
386|116|Golm Heart
387|116|Golm Heart+
388|116|Grand Gordlock
389|073|Cera Strongarm+
390|073|Cera Cediment
391|067|Rotaxion+
392|067|Vortax
393|067|Vortax+
394|054|Sinister Shade Axe+
395|054|Mighty Soulcrusher
396|111|Vengeful Broadfeller
397|076|Ikaji Immortal+
398|076|Unyielding Honor
399|057|Asylum Bellow
401|058|Asylum Peal
403|001|Daora's Thwartoise+
404|001|Daora's Worldbearer
405|074|Teostra's Nova+
406|074|Teostra's Redeemer
407|075|Etherward+
408|075|Phantom Providence
409|077|Crimson Mechwing
410|106|Elendskraft
411|106|Elendskraft+
412|106|Unheilskraft
413|107|L'Oppresseur
414|107|Le Salut
415|117|Abyssal Splitter
416|104|Demonlord Blade
417|080|Pounder of Rice+
418|080|Ricebane Emperor
419|065|Felyne Fancy+
420|065|Ominous Puss
421|064|Maxilla Edge+
422|064|Skull Edge
423|063|Shieldraad+
424|063|Armordraad
425|120|Royal Order's Battleaxe
427|120|Royal Order's Battleaxe+
428|121|Antique Machina CB
429|119|Kaktusemolgia
430|101|Luna Eostre
431|102|Hellsire Blade
433|105|Nunki's Asterism
440|066|Barroth Guardian+
441|073|Cera Cediment+
442|082|Champion Charge Blade II
443|082|Champion Charge Blade III
444|082|Guardian Charge Blade
448|122|Lost Code: Sara
449|124|Friede/Désastre
450|123|Stuffed Garangolm
451|125|Regal Daruq
452|126|Altostratus Blade
453|127|Silver Splitter
"""),
    'Light Bowgun': ('W_LightBowgun', 0x08C00000, """
0|059|Hunter's Rifle I
1|059|Hunter's Rifle II
2|059|Sniper Shot
3|060|Jaeger I
4|060|Jaeger II
5|060|Jaeger Prime
6|007|Cross Bowgun I
7|007|Cross Bowgun II
8|007|Cross Blitz
9|061|Yakt Shooter I
10|061|Yakt Shooter II
11|061|Wyvern Chaser
12|050|Kamura L. Bowgun I
13|050|Kamura L. Bowgun II
14|050|Kamura L. Bowgun III
15|050|Kamura L. Bowgun IV
16|050|Kamura L. Bowgun V
17|050|Kamura Ninja L. Bowgun
18|084|Rampage L. Bowgun I
19|084|Rampage L. Bowgun II
20|084|Rampage L. Bowgun III
21|084|Rampage L. Bowgun S
22|083|Wooden Dog Bowgun I
23|083|Wooden Dog Bowgun II
24|083|Watchdog's Howl
25|062|Springnight Shot I
26|062|Springnight Shot II
27|062|Springnight Spawn
28|051|Wind Thief L. Bowgun I
29|051|Wind Thief L. Bowgun II
30|051|Wind Thief L. Bowgun III
31|051|Gale Bowgun
32|052|Lotus Bowgun I
33|052|Lotus Bowgun II
34|052|Great Lotus Bowgun
35|053|Sinister Bowgun I
36|053|Sinister Bowgun II
37|053|Sinister Shadow Bolt
38|054|Gossgun I
39|054|Gossgun II
40|054|Gossgun III
41|054|Abominable Bowgun
42|055|Almudron Bowgun I
43|055|Almudron Bowgun II
44|055|Doom Bringer Bowgun
45|056|Lumier Bowgun I
46|056|Lumier Bowgun II
47|056|Araknabolt
48|057|Azure Elder Bowgun I
49|057|Azure Elder Bowgun II
50|057|Abyssal Gale Bolt
51|058|Thunderbolt Bowgun I
52|058|Abyssal Storm Bolt
53|082|Redwing Shooter I
54|082|Reddnaught Bowgun
55|065|Royal Launcher I
56|065|Royal Launcher II
57|065|Royal Torrent
58|066|Barro Barrel I
59|066|Barro Barrel II
60|066|Barro Blaster
61|067|Khezu Syringe I
62|067|Khezu Syringe II
63|067|Khezu Syringe III
64|067|Khezu Hypo
65|068|Shotgun (Viper) I
66|068|Shotgun (Viper) II
67|068|Shotgun (Viper) III
68|068|Bullet Rain (Viper)
69|069|Scale Tornado I
70|069|Scale Tornado II
71|069|Uroktor Vortex
72|030|Wishing Star I
73|030|Wishing Star II
74|030|Comet Bolt
75|070|Grenade Launcher I
76|070|Grenade Launcher II
77|070|Grenade Launcher III
78|070|Grenade Revolver
79|071|Valkyrie Fire I
80|071|Valkyrie Fire II
81|071|Valkyrie Blaze
82|012|Blizzard Cannon I
83|012|Blizzard Cannon II
84|012|Blizzard Volley
85|033|Flammengewehr I
86|033|Flammengewehr II
87|033|Furious Flammengewehr
88|073|Hidden Eye I
89|073|Hidden Eye II
90|073|Night Owl
91|074|Desolate Mist I
92|074|Desolate Mist II
93|074|Nifl Mist
94|075|Rathling Gun I
95|075|Rathling Gun II
96|075|Rathling Phoenix
97|076|Usurper's Crime I
98|076|Usurper's Crime II
99|076|Despot's Wildfire
100|077|Tigrex Tank I
101|077|Tigrex Tank II
102|077|Tigrex Wargun
103|003|Icesteel Wasp I
104|003|Daora's Hornet
105|078|Teostra's Dart I
106|078|Teostra's Flamebolt
107|079|Blessed Lamp I
108|079|Cursed Lamp
109|080|Rajang Barrage I
110|080|Rajang Barrage II
111|080|Ten Thousand Volts
112|034|Rookslayer Bowgun I
113|034|Rookslayer Bowgun II
114|034|Bazelfetter Rookslayer
115|084|Rampage L. Bowgun IV
116|084|Rampage L. Bowgun V
117|085|Defender Light Bowgun I
118|085|Champion Light Bowgun
300|100|Kamura Warrior Crossbow
301|100|Kamura Warrior Crossbow+
302|100|Fine Kamura Crossbow
303|116|Duke's Arquebus
304|116|Vigil Kugel
305|073|Nightstrix
306|073|Nightstrix+
307|073|Avidya Eye
308|056|Araknablaster
309|056|Araknablaster+
310|056|Ceaseless Shadow
311|113|Carmin Lantern
312|113|Luci Da Lavater
313|052|Redeemer's Lotus
314|052|Redeemer's Lotus+
315|052|Lord Redeemer's Iron
316|112|Glory Lotus Bowgun
317|112|Glory Lotus Bowgun+
318|112|Savior's Lotus
319|067|Khezu Hypo+
320|067|Hypodermic Miracle
321|067|Hypodermic Miracle+
322|068|Bullet Rain (Viper)+
323|068|Bullet Storm (Viper)
324|066|Barro Blaster+
325|066|Barrozooka+
326|054|Gross Gossgun
327|054|Gross Gossgun+
328|054|Abominable Snowshot
329|060|Jaeger Prime II
330|060|Jaeger Prime III
331|060|Ironclad Jaeger
332|117|Frostbiter
333|117|Frostbiter+
334|117|Icecloak Bowgun
335|109|Astalos Joltrender
336|109|Astalos Joltrender+
337|109|Astalos Flashblaster
338|076|Despot's Wildfire+
339|076|Oppressor's Rift
340|055|Fatal Bringer Bowgun
341|055|Fatal Bringer Bowgun+
342|055|Peace Bringer
343|114|Magma Weaver
344|114|Magma Flare
345|069|Uroktor Vortex+
346|069|Uroktor Tempest
347|074|Nifl Mist+
348|074|Encroaching Mist
349|074|Encroaching Mist+
350|110|Pure Bowgun Yao
351|051|Gale Bowgun+
352|051|Great Gale Bowgun
353|033|Furious Flammenkanone+
354|033|Hellfire Harbinger
356|033|Hellfire Harbinger+
357|071|Valkyrie Blaze+
358|071|Fierce Moss Green
359|071|Fierce Moss Green+
360|120|Rosengewehr
361|120|Rosengewehr+
362|120|Rosensiegen
363|061|Wyvern Chaser+
364|061|Dark Hunter
365|061|Dark Hunter+
366|108|Rasasa Bowgun
367|108|Rasasa Bowgun+
368|108|Rebel Stopper
369|103|Striped Shell
370|103|Striped Shell+
371|103|Daimyo Pincer
372|030|Comet Bolt+
373|030|Valtos Gill
374|030|Valtos Gill+
375|075|Rathling Phoenix+
376|075|Seering Rathling Phoenix
377|012|Blizzard Squall
378|012|Blizzard Squall+
379|012|Tabula Blizzara
380|070|Grenade Revolver+
382|070|Volarevolver
383|077|Tigrex Wargun+
384|077|Great Tigrex Wargun
385|077|Great Tigrex Wargun+
386|065|Royal Torrent+
387|065|Royal Tempest
388|065|Royal Tempest+
389|118|Golm Assaulter
390|118|Golm Assaulter+
391|118|Grand Cross
392|053|Sinister Shadow Bolt+
393|053|Tormented Shadow Bolt
394|111|Blue Blaze Bolt
395|080|Ten Thousand Volts+
396|080|Ten Million Volts
397|057|Shearing Wind
399|034|Bazelvalor Rookslayer
400|115|Bazelcore
401|058|Cascading Thunder
403|003|Daora's Hornet+
404|003|Daora's Yellowjacket
405|078|Teostra's Flamebolt+
406|078|Teostra's Flamepiercer
407|079|Cursed Lamp+
408|079|Genie's Lamp
409|082|Elder's Grace
410|106|Fäulnisschleuder
411|106|Fäulnisschleuder+
412|106|Teufelsschleuder
413|107|La Lumière
414|107|La Vertu
415|119|Abyssal Hailstorm
416|104|Demonlord Cannon
417|083|Watchdog's Howl+
419|083|Roaring Bowgun
420|062|Springnight Spawn+
421|062|Springnight Finshot
422|122|Royal Order's Crossbow
424|122|Royal Order's Crossbow+
425|123|Antique Machina LB
426|124|Hornet Gun
427|124|Hornet Gun+
428|124|Carapace Cannon
429|121|Kaktus Siegen
430|102|Silver Rathling Phoenix
431|101|Gold Valkyrie
433|105|Kaus Borealis's Asterism
442|066|Barrozooka
443|085|Champion Light Bowgun II
444|085|Champion Light Bowgun III
445|085|Guardian Light Bowgun
452|113|Carmin Lantern+
453|114|Magma Weaver+
460|125|Lost Code: Kera
461|127|Fäulnis/Vertu
462|126|Stuffed Khezu
463|128|Graceful Almaria
464|129|Wicked Needle
465|130|Silver Shooter
"""),
    'Heavy Bowgun': ('W_HeavyBowgun', 0x08D00000, """
0|020|Iron Assault I
1|020|Iron Assault II
2|020|Steel Assault
3|058|Meteor Bazooka I
4|058|Meteor Bazooka II
5|058|Meteor Cannon
6|060|Striker's Bowgun I
7|060|Striker's Bowgun II
8|060|Elite Bowgun
9|021|Bone Shooter I
10|021|Bone Shooter II
11|021|Bone Buster
12|050|Kamura H. Bowgun I
13|050|Kamura H. Bowgun II
14|050|Kamura H. Bowgun III
15|050|Kamura H. Bowgun IV
16|050|Kamura H. Bowgun V
17|050|Kamura Ninja H. Bowgun
18|083|Rampage H. Bowgun I
19|083|Rampage H. Bowgun II
20|083|Rampage H. Bowgun III
21|083|Rampage H. Bowgun S
22|061|Ladybug Cannon I
23|061|Ladybug Cannon II
24|061|Ladybug Mortar
25|063|Felyne Bowgun I
26|063|Felyne Bowgun II
27|063|Felyne Cannon
28|081|Journey Jelly I
29|081|Journey Jelly II
30|081|Guiding Light
31|062|Carrozza Bazooka I
32|062|Carrozza Bazooka II
33|062|Cendrillon
34|051|Wind Thief Crossbow I
35|051|Wind Thief Crossbow II
36|051|Wind Thief Crossbow III
37|051|Gale Crossbow
38|052|Reversal Shot I
39|052|Reversal Shot II
40|052|Reversal Shot III
41|052|Reversal Barrage
42|053|Highpriest Bowgun I
43|053|Highpriest Bowgun II
44|053|Bishaten's Grace
45|054|Sinister Volley I
46|054|Sinister Volley II
47|054|Sinister Dreadvolley
48|055|Fulgent Shot I
49|055|Fulgent Shot II
50|055|Araknamortar
51|056|Azure Elder Cannon I
52|056|Azure Elder Cannon II
53|056|Abyssal Gale Barrage
54|057|Thunderbolt Cannon I
55|057|Abyssal Storm Barrage
56|080|Redwing Cannon I
57|080|Diabolica
58|064|Rapidcaster I
59|064|Rapidcaster II
60|064|Cyclecaster
61|065|Anteka Burst I
62|065|Anteka Burst II
63|065|Anteka Blaster
64|066|Arzuros Gun I
65|066|Arzuros Gun II
66|066|Arzuros Fishergun
67|067|Spheniscine Slayer I
68|067|Spheniscine Slayer II
69|067|Spheniscine Ruler
70|068|Marino Burst I
71|068|Marino Burst II
72|068|Marino Cannon
73|069|Carom Shot I
74|069|Carom Shot II
75|069|Rebound Shot
76|033|Pukei Launcher I
77|033|Pukei Launcher II
78|033|Venomhail
79|070|Rock Eater I
80|070|Rock Eater II
81|070|Earth Eater
82|071|Queen's Longfire I
83|071|Queen's Longfire II
84|071|Queen's Farflier
85|072|Guerrera Cannon I
86|072|Guerrera Cannon II
87|072|Thorn Cannon
88|035|Kadachi Cannon I
89|035|Kadachi Cannon II
90|035|Kadachi Raijodo
91|005|Flammenkanone I
92|005|Flammenkanone II
93|005|Gnashing Flammenkanone
94|014|Hidden Gambit I
95|014|Hidden Gambit II
96|014|Baleful Night
97|074|Cirrus Blaster I
98|074|Cirrus Blaster II
99|074|Mountainous Roar
100|075|Usurper's Tremor I
101|075|Usurper's Tremor II
102|075|Despot's Paroxysm
103|013|Tigrex Howl I
104|013|Tigrex Howl II
105|013|Tigrex Skull
106|002|Dual Threat I
107|002|Dual Threat II
108|002|Diablazooka
109|077|Daora's Delphinidae I
110|077|Daora Grande
111|001|Teostra's Artillery I
112|001|Teostra's Flames
113|078|Kamaeleon I
114|078|Veiled Kamaeleon
115|082|Rajang Shooter I
116|082|Rajang Shooter II
117|082|Rajang's Rage
118|083|Rampage H. Bowgun IV
119|083|Rampage H. Bowgun V
120|084|Defender Heavy Bowgun I
121|084|Champion Heavy Bowgun
300|100|Kamura Warrior Ballista
301|100|Kamura Warrior Ballista+
302|100|Fine Kamura Ballista
303|114|Duke's Cannon
304|114|Chalice of Desire
305|013|Tigrex Skull+
306|013|Huge Tigrex Skull
307|013|Huge Tigrex Skull+
308|074|Mountainous Roar+
309|074|Mountainous Torrent
310|074|Mountainous Torrent+
311|110|Pure Cannon Tamamo
312|052|Reversal Barrage+
313|052|Grand Reversal Barrage
314|052|Grand Reversal Barrage+
315|071|Queen's Farflier+
316|071|Queen's Scionfire
317|071|Queen's Scionfire+
318|118|Rosenkugel
319|118|Rosenkugel+
320|118|Rosenprima
321|072|Guerrera Herald
322|072|Guerrera Herald+
323|072|Valía Cannon
324|066|Arzuros Fishergun+
325|066|Arbearalest
326|075|Despot's Paroxysm+
327|075|Oppressor's Making
328|060|Elite Bowgun+
329|060|Imperial Bowgun
331|060|Imperial Bowgun+
332|109|Wyvern Assault
333|109|Wyvern Assault+
334|109|Wyvern Crasher
335|005|Gnashing Flammenkanone+
336|005|Thermablaster
338|005|Thermablaster+
339|058|Meteor Cannon II
340|058|Meteor Cannon III
341|058|Galaxy Cannon
342|115|Frostmoon Howlitzer
343|115|Frostmoon Howlitzer+
344|115|Egil
345|070|Earth Eater+
347|070|Gaia Eater
348|068|Marino Cannon+
349|068|Purple October
350|068|Purple October+
351|116|Golm Cannon
352|116|Golm Cannon+
353|116|Golclops
354|069|Rebound Shot+
355|069|Red-Hot Rebound Shot
356|069|Red-Hot Rebound Shot+
357|051|Gale Crossbow+
358|051|Reaper Ballista Notus
359|055|Araknaboom
360|055|Araknaboom+
361|055|Forlorn Firestorm
362|113|Bordeaux Candlestick
363|113|Lampa Da Lavater
364|033|Venomhail+
365|033|Venomsurge
366|033|Venomsurge+
367|108|Sayyad Cannon
368|108|Sayyad Cannon+
369|108|Insurrection Cannon
370|065|Anteka Blaster+
371|065|Flidaismaker
372|002|Diablazooka+
373|002|Horned Demonica
374|035|Kadachi Raijodo+
375|035|Thunderballista
376|035|Thunderballista+
377|064|Hypercaster
379|064|Torrentcaster
380|102|Crab Buster
381|102|Crab Buster+
382|102|Heavy Crab Buster
383|103|Piercing Crab
384|103|Piercing Crab+
385|103|Ceanataur Blaster
386|014|Nirvana Ascension
387|014|Nirvana Ascension+
388|014|Avidya Gambit
389|053|Six Paths Blessing
390|053|Six Paths Blessing+
391|053|Six Paths Arblast
392|112|Bishaten's Glory
393|112|Bishaten's Glory+
394|112|Six Paths Crossing
395|067|Spheniscine Ruler+
396|067|Spheniscine God
397|054|Sinister Dreadvolley+
398|054|Mighty Soulstriker
399|111|Devil's Conduit
400|082|Rajang's Rage+
401|082|Rajang Cyclone
402|056|Skyshot Windstorm
404|057|Skyshot Thunderstorm
406|077|Daora Grande+
407|077|Daora's Ceti
408|001|Teostra's Flames+
409|001|Teostra's Firestorm
410|078|Veiled Kamaeleon+
411|078|Invisible Kamaeleon
412|080|Crimson Geyserwing
413|106|Tödlicher Abzug
414|106|Tödlicher Abzug+
415|106|Gemetzel Abzug
416|107|Le Désastre
417|107|Le Déluge
418|117|Abyssal Nova
419|104|Demonlord Thunder
420|062|Cendrillon+
421|062|Bibidi Babidi Boom
422|081|Sacred Radiance
423|081|Death Penalty
425|061|Ladybug Launcher
426|061|Great Ladybug Launcher
428|063|Felyne Cannon+
429|063|Felyne Artillery
430|120|Royal Order's Bowgun
432|120|Royal Order's Bowgun+
433|121|Antique Machina HB
434|122|Injector Cannon
435|122|Injector Cannon+
436|122|Zect Injector
437|119|Kaktus Prima
439|105|Polis's Asterism
448|002|Horned Demonica+
449|084|Champion Heavy Bowgun II
450|084|Champion Heavy Bowgun III
451|084|Guardian Heavy Bowgun
452|113|Bordeaux Candlestick+
456|101|Moonlight Sparkflier
457|123|Lost Code: Jura
458|125|Ursprung/Mort
459|124|Stuffed Mizutsune
460|126|Righteous Varka
461|127|Ill Omen
462|128|Silver Scatterer
"""),
    'Bow': ('W_Bow', 0x08E00000, """
0|057|Hunter's Stoutbow I
1|057|Hunter's Stoutbow II
2|057|Hunter's Proudbow
3|058|Crystalline Flower I
4|058|Crystalline Flower II
5|058|Heaven's Glaze
6|019|Iron Bow I
7|019|Iron Bow II
8|019|Steel Bow
9|059|Yekla Arc I
10|059|Yekla Arc II
11|059|Herald's Battlebow
12|007|Hunter's Bow I
13|007|Hunter's Bow II
14|007|Master Hunter's Bow
15|022|Bone Gun I
16|022|Bone Gun II
17|022|Hyper Bone Gun
18|050|Kamura Iron Bow I
19|050|Kamura Iron Bow II
20|050|Kamura Iron Bow III
21|050|Kamura Iron Bow IV
22|050|Kamura Iron Bow V
23|050|Kamura Ninja Bow
24|088|Rampage Bow I
25|088|Rampage Bow II
26|088|Rampage Bow III
27|088|Rampage Bow S
28|060|Morsel Bowfish I
29|060|Morsel Bowfish II
30|060|Ample Bowfish
31|062|Felyne Bow I
32|062|Felyne Bow II
33|062|Felyne Trickbow
34|061|Chaos Bow I
35|061|Chaos Bow II
36|061|Chaotic Rapture
37|087|Ivory Bow I
38|087|Ivory Bow II
39|087|Frozen Bow
40|063|Arachnid Bow I
41|063|Arachnid Bow II
42|063|Arachnid Silverstring
43|051|Dawn Ray Bow I
44|051|Dawn Ray Bow II
45|051|Summit's Grand Glow
46|052|Sinister Bow I
47|052|Sinister Bow II
48|052|Sinister Soulpiercer
49|053|Mud Shot I
50|053|Mud Shot II
51|053|Hail of Mud
52|054|Weaver of Flame I
53|054|Weaver of Flame II
54|054|Araknatorch
55|055|Azure Elder Bow I
56|055|Azure Elder Bow II
57|055|Abyssal Gale Bow
58|056|Thunderbolt Bow I
59|056|Abyssal Storm Bow
60|086|Redwing Bow I
61|086|Reddnaught Dragon Arc
62|064|Arko Nulo I
63|064|Arko Nulo II
64|064|Arko Unu
65|067|Arko Nulo Red I
66|067|Arko Nulo Red II
67|067|Arko Unu Red
68|065|Arko Nulo Yellow I
69|065|Arko Nulo Yellow II
70|065|Arko Unu Yellow
71|066|Arko Nulo White I
72|066|Arko Nulo White II
73|066|Arko Unu White
74|068|Arko Nulo Black I
75|068|Arko Nulo Black II
76|068|Arko Unu Black
77|069|Kelbi Stingshot I
78|069|Kelbi Stingshot II
79|069|Kelbi Strongshot
80|070|Arzuros Bow I
81|070|Arzuros Bow II
82|070|Arzuros' Honeypot
83|071|Baggi Bow I
84|071|Baggi Bow II
85|071|Hypnoshot
86|072|Wroggi Revolver I
87|072|Wroggi Revolver II
88|072|Hoodwinker's Revolver
89|032|Kulu's Flight I
90|032|Kulu's Flight II
91|032|Kulu Piercer
92|073|Spongia Bow I
93|073|Spongia Bow II
94|073|Spongia Bow III
95|073|Porifera Bow
96|074|Khezu Bow I
97|074|Khezu Bow II
98|074|Galvanized Core
99|035|Pukei Bow I
100|035|Pukei Bow II
101|035|Venomtongue Strike
102|075|Queen Blaster I
103|075|Queen Blaster II
104|075|Queen's Melody
105|076|Ice Crest I
106|076|Ice Crest II
107|076|Ice Crest III
108|076|Edelweiss
109|006|Kadachi Strikebow I
110|006|Kadachi Strikebow II
111|006|Kadachi Strikebow III
112|006|Flying Kadachi Striker
113|038|Flammenbogen I
114|038|Flammenbogen II
115|038|Flaming Rage Bow
116|014|Hidden Bow I
117|014|Hidden Bow II
118|014|Night Flight
119|078|Blessed Rain I
120|078|Blessed Rain II
121|078|Heaven's Manna
122|079|Prominence Bow I
123|079|Prominence Bow II
124|079|Dark Filament
125|080|Usurper's Rumble I
126|080|Usurper's Rumble II
127|080|Despot's Earlybolt
128|081|Tigrex Archer I
129|081|Tigrex Archer II
130|081|Tigrex Whisker
131|002|Diablos Coilbender I
132|002|Diablos Coilbender II
133|002|Tyrant Bow
134|001|Icesteel Bow I
135|001|Daora's Sagittarii
136|082|Bow of Hope & Valor I
137|082|Bow of Light & Courage
138|083|Genie's Grimoire I
139|083|Demon's Guidance
140|084|Beast Thunderbow I
141|084|Beast Thunderbow II
142|084|Beastking Thunderbow
143|088|Rampage Bow IV
144|088|Rampage Bow V
145|090|Defender Bow I
146|090|Champion Bow
147|089|Azure Era Wyrmbow I
148|089|Azure Era "Soaring Dragon"
300|100|Kamura Warrior Bow
301|100|Kamura Warrior Bow+
302|100|Fine Kamura Bow
303|116|Duke's Bloodwings
304|116|Ravenous Vampire
305|054|Araknabuster
306|054|Araknabuster+
307|054|Creeping Darkness
308|114|Koraeil Mesmerbow
309|114|Cuore Da Lavater
310|078|Heaven's Manna+
311|078|Elysian Manna
312|078|Elysian Manna+
313|111|Pure Bow Kuzunoha
314|051|Grand Glowing Oath
315|051|Grand Glowing Oath+
316|051|Exalted Vow
317|113|Summit's Glory Glow
318|113|Summit's Glory Glow+
319|113|Six Glowing Oaths
320|014|Shade Raid
321|014|Shade Raid+
322|014|Avidya Bow
323|006|Flying Kadachi Striker+
324|006|Thundering Strikebow
325|006|Thundering Strikebow+
326|076|Edelmorden
327|076|Edelmorden+
328|076|Amber Arc Valanga
329|072|Hoodwinker's Revolver+
330|072|Spith & Venom
331|070|Arzuros' Honeypot+
332|070|Arzuros' Sweetscent
333|057|Hunter's Proudbow+
334|057|Hunter's Bravebow
335|057|Hunter's Bravebow+
336|110|Thunderstroke Tonnerre
337|110|Thunderstroke Tonnerre+
338|110|Perkunas
339|059|Herald's Battlebow+
340|059|Harbinger's Battlebow
342|059|Harbinger's Battlebow+
343|058|Diamond Dust Bow
344|058|Diamond Dust Bow+
345|058|Heaven's Breath
346|117|Frostmoon Crescentbow
347|117|Frostmoon Crescentbow+
348|117|Lunoloony Frostbow
349|053|Storm of Mud
350|053|Storm of Mud+
351|053|Tornado of Mud
352|115|Welding Rust
353|115|Welded Trinity
354|075|Queen's Melody+
355|075|Queen's Rhapsody
356|075|Queen's Rhapsody+
357|120|Rosenbogen
358|120|Rosenbogen+
359|120|Rosenzichel
360|079|Dark Filament+
361|079|Flamestroke Flam
362|032|Kulu Piercer+
363|032|Kulu Katolos Piercer
364|074|Galvanized Core+
365|074|Khezu Que C'est
366|074|Khezu Que C'est+
367|007|Master Hunter's Bow+
368|007|Sharpshooter
369|007|Sharpshooter+
370|109|Shalya Bow
371|109|Shalya Bow+
372|109|Insurgent Bow
373|103|Daimyo's Warbow
374|103|Daimyo's Warbow+
375|103|Chelae Warbow
376|104|Blue Blade Bow
377|104|Blue Blade Bow+
378|104|Showroom Model
379|081|Tigrex Whisker+
380|081|Tigrex Vibrissa
381|081|Tigrex Vibrissa+
382|002|Tyrant Bow+
383|002|The Terrible
384|080|Despot's Earlybolt+
385|080|Oppressor's Answer
386|035|Venomtongue Strike+
387|035|Venomtongue Absolute+
388|038|Flaming Rage Bow+
389|038|Lohenbogen
390|038|Lohenbogen+
391|073|Porifera Bow+
392|073|Drothdymion
393|073|Drothdymion+
394|118|Golm Bone Bow
395|118|Golm Bone Bow+
396|118|Gorboza Bow
397|071|Hypnoshot+
398|071|Grand Deepdraw
399|068|Arko Du Black
400|068|Arko Tre Black
401|065|Arko Du Yellow
402|065|Arko Tre Yellow
403|067|Arko Du Red
404|067|Arko Tre Red
405|067|Arko Kvar Red
406|066|Arko Du White
407|066|Arko Tre White
408|066|Arko Kvar White
409|052|Sinister Soulpiercer+
410|052|Mighty Soulpiercer
411|112|Mail Soulpiercer
412|069|Kelbi Deershot
414|069|Great Kelbi Deershot
415|084|Beastking Thunderbow+
416|084|Beastczar Thunderbow
417|055|Skyriven Nightfall
419|056|Skyriven Dawn
421|001|Daora's Sagittarii+
422|001|Daora's Toxotes
423|082|Bow of Light & Courage+
424|082|Bow of Want & Blood
425|083|Demon's Guidance+
426|083|Devil's Counsel
427|086|Crimson Plume
428|107|Entbehrung
429|107|Entbehrung+
430|107|Untergang
431|108|Le Ravisseur
432|108|L'Innocence
433|119|Abyssal Void
434|105|Archbeast Avatar
435|060|Ample Bowfish+
437|060|Viand Bowfish
438|062|Felyne Trickbow+
439|062|Hoodwynk
440|061|Chaotic Rapture+
441|061|Chaotic Thrall
442|087|Frozen Bow+
443|087|Frozen Solstice
444|063|Arachnid Sheerstrike
446|063|Arachnid Silksong
447|124|Sonic Bow
448|124|Sonic Bow+
449|124|Sonic Resonator
450|122|Royal Order's Bow
452|122|Royal Order's Bow+
453|123|Antique Machina B
454|121|Kaktus Sichel
455|102|Hyperion
456|101|Selene Moonbroken
458|106|Polaris's Guidance
465|035|Venomtongue Absolute
468|002|The Terrible+
469|090|Champion Bow II
470|090|Champion Bow III
471|090|Guardian Bow
484|114|Koraeil Mesmerbow+
485|115|Welding Rust+
495|125|Lost Code: Iru
496|127|Auftauchen/Disparition
497|126|Stuffed Rajang
498|128|Alluring Evelia
499|129|Tempest Nightbow
500|130|Silver Striker
"""),
    'Kinsect': ('W_Insect', 0x08F00000, """
0|001|Culldrone
1|012|Mauldrone
2|003|Alucanid
3|014|Foebeetle
4|006|Rigiprayne
5|017|Ladytarge
6|009|Windchopper
7|020|Gullshad
8|004|Monarch Alucanid
9|015|Carnage Beetle
10|005|Empresswing
11|016|Bonnetfille
12|007|Cancadaman
13|018|Ladypavise
14|008|Fiddlebrix
15|019|Arkmaiden
16|010|Grancathar
17|021|Bullshroud
18|011|Pseudocath
19|022|Whispervesp
100|050|Exalted Alucanid
101|051|Gleambeetle
102|052|Bilbobrix
103|053|Ladytower
104|054|Foliacath
105|055|Fleetflammer
"""),
}


def _parse():
    types, weapons = {}, {}
    for tipe, (prefix, base, text) in _DATA.items():
        by_model, rows = {}, []
        for line in text.strip().splitlines():
            enum, model, nama = line.split("|", 2)
            n = int(enum)
            wid = "%08X" % (base + n)
            rows.append((wid, "%s_%03d" % (prefix, n), model, nama))
            by_model.setdefault(model, []).append(nama)
        types[tipe] = by_model
        weapons[tipe] = rows
    return types, weapons


TYPES, WEAPONS = _parse()      # TYPES[tipe][model] = [nama...] ; WEAPONS[tipe] = [(weapon_id, enum_name, model, nama)]

LANCE = TYPES["Lance"]
GREATSWORD = TYPES["Great Sword"]
SWORDSHIELD = TYPES["Sword & Shield"]
HAMMER = TYPES["Hammer"]
LONGSWORD = TYPES["Long Sword"]
SWITCHAXE = TYPES["Switch Axe"]
GUNLANCE = TYPES["Gunlance"]
DUALBLADES = TYPES["Dual Blades"]
HUNTINGHORN = TYPES["Hunting Horn"]
INSECTGLAIVE = TYPES["Insect Glaive"]
CHARGEBLADE = TYPES["Charge Blade"]
LIGHTBOWGUN = TYPES["Light Bowgun"]
HEAVYBOWGUN = TYPES["Heavy Bowgun"]
BOW = TYPES["Bow"]
KINSECT = TYPES["Kinsect"]


def type_names():
    return list(TYPES.keys())


def _ascii(s):
    import unicodedata
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()


def weapon_list(tipe="Lance"):
    """Baris untuk pemilih di aplikasi, terurut menurut nomor model:
    'NNN  Nama, Nama  |  ID: 084001BF, ...'
    Tiga karakter pertama selalu nomor model. Nama beraksen diberi padanan ASCII agar bisa dicari."""
    ids = {}
    for wid, _enum, model, _nama in WEAPONS[tipe]:
        ids.setdefault(model, []).append(wid)
    rows = []
    for model, names in sorted(TYPES[tipe].items()):
        shown = []
        for n in names:
            a = _ascii(n)
            shown.append(n if a == n else "%s (%s)" % (n, a))
        rows.append("%s  %s  |  ID: %s" % (model, ", ".join(shown), ", ".join(ids[model])))
    return rows


def lance_list():
    return weapon_list("Lance")


def find(query):
    """Cari senjata berdasarkan nama, Weapon ID (hex) atau enum. Return [(tipe, weapon_id, enum, model, nama)]."""
    q = _ascii(query).lower().strip()
    hasil = []
    for tipe, rows in WEAPONS.items():
        for wid, enum, model, nama in rows:
            if q in _ascii(nama).lower() or q == wid.lower() or q == enum.lower():
                hasil.append((tipe, wid, enum, model, nama))
    return hasil
