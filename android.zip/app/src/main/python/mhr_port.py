#!/usr/bin/env python3
"""
MHR PC -> Switch texture porter + .pak patch builder (pure Python, no dependencies).

Pengganti auto_port.bat / chop.bat / Asterisk_MHR_Tex_Chopper_*.exe / RisePakPatch.exe
(tidak perlu Winlator). Reimplementasi dari hasil bedah tool aslinya, diverifikasi
dengan hasil asli (lihat test_against_reference.py).

Pemakaian:
    python mhr_port.py <folder_yang_berisi_natives | file.zip> [output.pak]
"""
import os, sys, struct, zipfile, tempfile, shutil, math

PACKET = 16          # byte per "packet" swizzle
GOB_W = 4            # packet per GOB (64 byte)
GOB_H = 8            # baris per GOB

# ---------------------------------------------------------------- format ----
def _bc_bytes(fmt):
    # id DXGI -> byte per blok 4x4
    if fmt in (70, 71, 72, 79, 80, 81): return 8        # BC1, BC4
    if fmt in (73, 74, 75, 76, 77, 78, 82, 83, 84, 94, 95, 96, 97, 98, 99): return 16
    return None

_BPP = {}
for _ids, _b in (
    ((27, 28, 29, 30, 31, 32, 87, 88, 89, 90, 91, 92, 93, 23, 24, 25, 26, 33, 34, 35, 36, 37, 38,
      40, 41, 42, 43, 39, 45, 44, 46, 20, 67, 68, 69), 4),
    ((48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 85, 86), 2),
    ((60, 61, 62, 63, 64, 65), 1),
    ((9, 10, 11, 12, 13, 14, 15, 16, 17, 18), 8),
    ((1, 2, 3, 4), 16),
    ((5, 6, 7, 8), 12),
):
    for _i in _ids: _BPP[_i] = _b

def format_layout(fmt):
    """-> (texel_w, texel_h, byte_per_block) untuk satu 'blok' sumber."""
    bb = _bc_bytes(fmt)
    if bb: return 4, 4, bb
    if fmt in _BPP: return 1, 1, _BPP[fmt]
    raise ValueError("Format tekstur %d belum didukung (ASTC/lainnya)" % fmt)

def ru_div(x, y): return (x + y - 1) // y

def ulog2(x):
    return 0 if x <= 1 else math.ceil(math.log2(x))

# --------------------------------------------------------------- swizzle ----
_INNER = [[(px // 2) * 256 + (y // 2) * 64 + (px % 2) * 32 + (y % 2) * 16
           for px in range(GOB_W)] for y in range(GOB_H)]

def swizzle_height_log(rows):
    """sy untuk jumlah baris-packet tertentu (getSwizzleSizes)."""
    return max(0, min(4, ulog2(rows) - 3))

def swizzle_mip(rows_data, wp, hp, sy):
    """rows_data: bytes (wp*hp*16, linear) -> bytes swizzled (block-linear Tegra)."""
    bh = 1 << sy
    rpb = GOB_H * bh
    hyper_w = ru_div(wp, GOB_W)
    hyper_h = ru_div(hp, rpb)
    blk = 512 * bh
    out = bytearray(hyper_w * hyper_h * blk)
    for y in range(hp):
        base_y = (y // rpb) * hyper_w * blk + ((y // GOB_H) % bh) * 512
        inner = _INNER[y % GOB_H]
        src = y * wp * PACKET
        for x in range(wp):
            o = base_y + (x // GOB_W) * blk + inner[x % GOB_W]
            s = src + x * PACKET
            out[o:o + PACKET] = rows_data[s:s + PACKET]
    return bytes(out)

# ------------------------------------------------------------------- tex ----
class Tex:
    pass

def parse_tex(buf):
    if buf[:4] != b'TEX\0':
        raise ValueError("Bukan file TEX")
    t = Tex()
    (t.version, t.width, t.height, t.depth, counts, t.format,
     t.swizzle_ctl, t.cubemap_marker) = struct.unpack_from('<IHHHHIiI', buf, 4)
    if t.version != 28:
        raise ValueError("Versi tex %d tidak didukung (hanya 28)" % t.version)
    t.mip_count = counts >> 12
    t.image_count = (counts >> 8) & 0xF
    if t.image_count == 0: t.image_count = 1
    if t.swizzle_ctl == 1:
        raise ValueError("Tex sumber sudah ter-swizzle (bukan tex PC)")
    t.cubemap = t.cubemap_marker // 4
    t.images = []
    pos = 0x28
    for i in range(t.image_count):
        mips = []
        for m in range(t.mip_count):
            off, pitch, size = struct.unpack_from('<QII', buf, pos); pos += 16
            mips.append(buf[off:off + size] if size else b'')
            mips[-1] = (mips[-1], pitch)
        t.images.append(mips)
    return t

def _linear_packets(data, pitch, w, h, fmt):
    """data mentah PC -> baris packet 16 byte (linear), return (bytes, wp, hp)."""
    bw, bh, bb = format_layout(fmt)
    wb, hb = ru_div(w, bw), ru_div(h, bh)
    row = wb * bb
    wp = ru_div(row, PACKET)
    if pitch and pitch >= row and pitch != row:
        data = b''.join(data[r * pitch:r * pitch + row] for r in range(hb))
    need = row * hb
    data = data[:need].ljust(need, b'\0')
    if row != wp * PACKET:
        data = b''.join(data[r * row:(r + 1) * row].ljust(wp * PACKET, b'\0') for r in range(hb))
    return data, wp, hb

def pc_tex_to_switch_tex(buf):
    t = parse_tex(buf)
    bw, bh, bb = format_layout(t.format)
    # sy global dihitung dari ukuran mip 0
    wp0 = ru_div(ru_div(t.width, bw) * bb, PACKET)
    hp0 = ru_div(t.height, bh)
    sy0 = swizzle_height_log(hp0)
    base = 0x28 + 16 * t.image_count * t.mip_count
    heads, blobs = [], []
    for img in t.images:
        for m, (data, pitch) in enumerate(img):
            w, h = max(1, t.width >> m), max(1, t.height >> m)
            lin, wp, hp = _linear_packets(data, pitch, w, h, t.format)
            sw = swizzle_mip(lin, wp, hp, swizzle_height_log(hp))
            comp = sw.rstrip(b'\0')
            heads.append(struct.pack('<QII', base, len(comp), len(sw)))
            blobs.append(comp)
            base += len(comp)
    counts = (t.mip_count << 12) | t.image_count
    head = struct.pack('<4sIHHHHIiII', b'TEX\0', 28, t.width, t.height, t.depth, counts,
                       t.format, 1, t.cubemap * 4, 0)
    head += struct.pack('<BBHHH', sy0, 0, 0, 7, 1)
    return head[:0x20] + head[0x20:] + b''.join(heads) + b''.join(blobs)

# ------------------------------------------------------------------- pak ----
def murmur3_32(data, seed=0xFFFFFFFF):
    M = 0xFFFFFFFF; c1, c2 = 0xCC9E2D51, 0x1B873593; h = seed
    n = len(data) // 4 * 4
    for i in range(0, n, 4):
        k = struct.unpack_from('<I', data, i)[0]
        k = (k * c1) & M; k = ((k << 15) | (k >> 17)) & M; k = (k * c2) & M
        h ^= k; h = ((h << 13) | (h >> 19)) & M; h = (h * 5 + 0xE6546B64) & M
    k = 0; t = data[n:]
    if len(t) >= 3: k ^= t[2] << 16
    if len(t) >= 2: k ^= t[1] << 8
    if len(t) >= 1:
        k ^= t[0]; k = (k * c1) & M; k = ((k << 15) | (k >> 17)) & M; k = (k * c2) & M; h ^= k
    h ^= len(data); h ^= h >> 16; h = (h * 0x85EBCA6B) & M
    h ^= h >> 13; h = (h * 0xC2B2AE35) & M; h ^= h >> 16
    return h

def build_pak(entries, out_path):
    """entries: list[(path_dalam_game 'natives/nsw/...', bytes)]"""
    n = len(entries)
    off = 16 + 48 * n
    table, blobs = [], []
    for path, data in entries:
        lo = murmur3_32(path.lower().encode('utf-16le'))
        up = murmur3_32(path.upper().encode('utf-16le'))
        table.append(struct.pack('<IIQQQQQ', lo, up, off, len(data), len(data), 0, 0))
        blobs.append(data); off += len(data)
    with open(out_path, 'wb') as f:
        f.write(struct.pack('<4sBBHII', b'KPKA', 4, 0, 0, n, 0))
        f.write(b''.join(table))
        for b in blobs: f.write(b)

# ---------------------------------------------------------------- driver ----
def find_natives(root):
    for dp, dn, _ in os.walk(root):
        if 'natives' in dn:
            return os.path.join(dp, 'natives')
    return None

def port_mod(src, out_pak, log=print):
    tmp = None
    if os.path.isfile(src) and src.lower().endswith('.zip'):
        tmp = tempfile.mkdtemp(prefix='mhr_')
        with zipfile.ZipFile(src) as z: z.extractall(tmp)
        src = tmp
    try:
        nat = find_natives(src)
        if not nat: raise SystemExit("ERROR: folder 'natives' tidak ditemukan")
        parent = os.path.dirname(nat)
        files = []
        for dp, _, fn in os.walk(nat):
            for f in fn:
                files.append(os.path.join(dp, f))
        files.sort(key=lambda p: p.lower())
        entries = []
        for i, p in enumerate(files, 1):
            rel = os.path.relpath(p, parent).replace(os.sep, '/')
            parts = rel.split('/')
            if len(parts) > 1 and parts[1].upper() == 'STM': parts[1] = 'NSW'
            rel = '/'.join(parts)
            data = open(p, 'rb').read()
            if rel.lower().endswith('.tex.28'):
                log("[%d/%d] tekstur  %s" % (i, len(files), rel))
                data = pc_tex_to_switch_tex(data)
            else:
                log("[%d/%d] salin    %s" % (i, len(files), rel))
            entries.append((rel, data))
        build_pak(entries, out_pak)
        log("SELESAI -> %s (%d file)" % (out_pak, len(entries)))
        return entries
    finally:
        if tmp: shutil.rmtree(tmp, ignore_errors=True)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    out = sys.argv[2] if len(sys.argv) > 2 else 're_chunk_000.pak.patch_00y.pak'
    port_mod(sys.argv[1], out)
