#!/usr/bin/env python3
"""
MHR PC -> Switch texture porter + .pak patch builder (pure Python, no dependencies).

Pengganti auto_port.bat / chop.bat / Asterisk_MHR_Tex_Chopper_*.exe / RisePakPatch.exe
(tidak perlu Winlator). Reimplementasi dari hasil bedah tool aslinya, diverifikasi
dengan hasil asli (lihat test_against_reference.py).

Pemakaian:
    python mhr_port.py <folder_yang_berisi_natives | file.zip> [output.pak]
"""
import os, sys, struct, zipfile, tempfile, shutil, math

PACKET = 16          # byte per "packet" swizzle
GOB_W = 4            # packet per GOB (64 byte)
GOB_H = 8            # baris per GOB

# ---------------------------------------------------------------- format ----
def _bc_bytes(fmt):
    # id DXGI -> byte per blok 4x4
    if fmt in (70, 71, 72, 79, 80, 81): return 8        # BC1, BC4
    if fmt in (73, 74, 75, 76, 77, 78, 82, 83, 84, 94, 95, 96, 97, 98, 99): return 16
    return None

_BPP = {}
for _ids, _b in (
    ((27, 28, 29, 30, 31, 32, 87, 88, 89, 90, 91, 92, 93, 23, 24, 25, 26, 33, 34, 35, 36, 37, 38,
      40, 41, 42, 43, 39, 45, 44, 46, 20, 67, 68, 69), 4),
    ((48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 85, 86), 2),
    ((60, 61, 62, 63, 64, 65), 1),
    ((9, 10, 11, 12, 13, 14, 15, 16, 17, 18), 8),
    ((1, 2, 3, 4), 16),
    ((5, 6, 7, 8), 12),
):
    for _i in _ids: _BPP[_i] = _b

def format_layout(fmt):
    """-> (texel_w, texel_h, byte_per_block) untuk satu 'blok' sumber."""
    bb = _bc_bytes(fmt)
    if bb: return 4, 4, bb
    if fmt in _BPP: return 1, 1, _BPP[fmt]
    raise ValueError("Format tekstur %d belum didukung (ASTC/lainnya)" % fmt)

def ru_div(x, y): return (x + y - 1) // y

def ulog2(x):
    return 0 if x <= 1 else math.ceil(math.log2(x))

# --------------------------------------------------------------- swizzle ----
_INNER = [[(px // 2) * 256 + (y // 2) * 64 + (px % 2) * 32 + (y % 2) * 16
           for px in range(GOB_W)] for y in range(GOB_H)]

def swizzle_height_log(rows):
    """sy untuk jumlah baris-packet tertentu (getSwizzleSizes)."""
    return max(0, min(4, ulog2(rows) - 3))

def swizzle_mip(rows_data, wp, hp, sy):
    """rows_data: bytes (wp*hp*16, linear) -> bytes swizzled (block-linear Tegra)."""
    bh = 1 << sy
    rpb = GOB_H * bh
    hyper_w = ru_div(wp, GOB_W)
    hyper_h = ru_div(hp, rpb)
    blk = 512 * bh
    out = bytearray(hyper_w * hyper_h * blk)
    for y in range(hp):
        base_y = (y // rpb) * hyper_w * blk + ((y // GOB_H) % bh) * 512
        inner = _INNER[y % GOB_H]
        src = y * wp * PACKET
        for x in range(wp):
            o = base_y + (x // GOB_W) * blk + inner[x % GOB_W]
            s = src + x * PACKET
            out[o:o + PACKET] = rows_data[s:s + PACKET]
    return bytes(out)

# ------------------------------------------------------------------- tex ----
class Tex:
    pass

def parse_tex(buf):
    if buf[:4] != b'TEX\0':
        raise ValueError("Bukan file TEX")
    t = Tex()
    (t.version, t.width, t.height, t.depth, counts, t.format,
     t.swizzle_ctl, t.cubemap_marker) = struct.unpack_from('<IHHHHIiI', buf, 4)
    if t.version != 28:
        raise ValueError("Versi tex %d tidak didukung (hanya 28)" % t.version)
    t.mip_count = counts >> 12
    t.image_count = (counts >> 8) & 0xF
    if t.image_count == 0: t.image_count = 1
    if t.swizzle_ctl == 1:
        raise ValueError("Tex sumber sudah ter-swizzle (bukan tex PC)")
    t.cubemap = t.cubemap_marker // 4
    t.images = []
    pos = 0x28
    for i in range(t.image_count):
        mips = []
        for m in range(t.mip_count):
            off, pitch, size = struct.unpack_from('<QII', buf, pos); pos += 16
            mips.append(buf[off:off + size] if size else b'')
            mips[-1] = (mips[-1], pitch)
        t.images.append(mips)
    return t

def _linear_packets(data, pitch, w, h, fmt):
    """data mentah PC -> baris packet 16 byte (linear), return (bytes, wp, hp)."""
    bw, bh, bb = format_layout(fmt)
    wb, hb = ru_div(w, bw), ru_div(h, bh)
    row = wb * bb
    wp = ru_div(row, PACKET)
    if pitch and pitch >= row and pitch != row:
        data = b''.join(data[r * pitch:r * pitch + row] for r in range(hb))
    need = row * hb
    data = data[:need].ljust(need, b'\0')
    if row != wp * PACKET:
        data = b''.join(data[r * row:(r + 1) * row].ljust(wp * PACKET, b'\0') for r in range(hb))
    return data, wp, hb

def pc_tex_to_switch_tex(buf):
    t = parse_tex(buf)
    bw, bh, bb = format_layout(t.format)
    # sy global dihitung dari ukuran mip 0
    wp0 = ru_div(ru_div(t.width, bw) * bb, PACKET)
    hp0 = ru_div(t.height, bh)
    sy0 = swizzle_height_log(hp0)
    base = 0x28 + 16 * t.image_count * t.mip_count
    heads, blobs = [], []
    for img in t.images:
        for m, (data, pitch) in enumerate(img):
            w, h = max(1, t.width >> m), max(1, t.height >> m)
            lin, wp, hp = _linear_packets(data, pitch, w, h, t.format)
            sw = swizzle_mip(lin, wp, hp, swizzle_height_log(hp))
            comp = sw.rstrip(b'\0')
            heads.append(struct.pack('<QII', base, len(comp), len(sw)))
            blobs.append(comp)
            base += len(comp)
    counts = (t.mip_count << 12) | t.image_count
    head = struct.pack('<4sIHHHHIiII', b'TEX\0', 28, t.width, t.height, t.depth, counts,
                       t.format, 1, t.cubemap * 4, 0)
    head += struct.pack('<BBHHH', sy0, 0, 0, 7, 1)
    return head[:0x20] + head[0x20:] + b''.join(heads) + b''.join(blobs)

# ------------------------------------------------------------------- pak ----
def murmur3_32(data, seed=0xFFFFFFFF):
    M = 0xFFFFFFFF; c1, c2 = 0xCC9E2D51, 0x1B873593; h = seed
    n = len(data) // 4 * 4
    for i in range(0, n, 4):
        k = struct.unpack_from('<I', data, i)[0]
        k = (k * c1) & M; k = ((k << 15) | (k >> 17)) & M; k = (k * c2) & M
        h ^= k; h = ((h << 13) | (h >> 19)) & M; h = (h * 5 + 0xE6546B64) & M
    k = 0; t = data[n:]
    if len(t) >= 3: k ^= t[2] << 16
    if len(t) >= 2: k ^= t[1] << 8
    if len(t) >= 1:
        k ^= t[0]; k = (k * c1) & M; k = ((k << 15) | (k >> 17)) & M; k = (k * c2) & M; h ^= k
    h ^= len(data); h ^= h >> 16; h = (h * 0x85EBCA6B) & M
    h ^= h >> 13; h = (h * 0xC2B2AE35) & M; h ^= h >> 16
    return h

def build_pak(entries, out_path):
    """entries: list[(path_dalam_game 'natives/nsw/...', bytes)]"""
    n = len(entries)
    off = 16 + 48 * n
    table, blobs = [], []
    for path, data in entries:
        lo = murmur3_32(path.lower().encode('utf-16le'))
        up = murmur3_32(path.upper().encode('utf-16le'))
        table.append(struct.pack('<IIQQQQQ', lo, up, off, len(data), len(data), 0, 0))
        blobs.append(data); off += len(data)
    with open(out_path, 'wb') as f:
        f.write(struct.pack('<4sBBHII', b'KPKA', 4, 0, 0, n, 0))
        f.write(b''.join(table))
        for b in blobs: f.write(b)

# ---------------------------------------------------------------- driver ----
def find_natives(root):
    for dp, dn, _ in os.walk(root):
        if 'natives' in dn:
            return os.path.join(dp, 'natives')
    return None

# ----------------------------------------------------- ganti ID weapon ----
import re
_WEAPON_DIR = re.compile(r'^([A-Za-z]+)(\d{3})$')      # mis. Lan624, Lan105, Swd024

def _split(rel):
    return rel.replace('\\', '/').split('/')

def find_weapon_ids(rels):
    """Cari folder model senjata natives/<plat>/weapon/<Tipe>/<Prefix><NNN>/ yang berisi
    mesh/mdf2. Return {(Tipe, Prefix, NNN)}."""
    found = set()
    for r in rels:
        parts = _split(r)
        if len(parts) >= 6 and parts[2].lower() == 'weapon':
            m = _WEAPON_DIR.match(parts[4])
            if m and re.search(r'\.(mesh|mdf2)\.', parts[-1].lower()):
                found.add((parts[3], m.group(1), m.group(2)))
    return found

def plan_retarget(rels, dst_id, src_id=None, drop_prefab=True):
    """Rencana penggantian ID model senjata (untuk layered weapon).
    rels   : daftar path relatif 'natives/STM/...'
    dst_id : ID model tujuan, 3 digit (mis. '105' = Lan105 Dubhe's Asterism)
    src_id : ID model sumber; None = deteksi otomatis (harus tepat satu)
    Return (mapping{rel -> rel_baru | None(buang)}, src_id)."""
    dst_id = str(dst_id).strip().zfill(3)
    if not re.fullmatch(r'\d{3}', dst_id):
        raise SystemExit("ERROR: ID tujuan harus 3 digit angka (mis. 105)")
    ids = find_weapon_ids(rels)
    if src_id is not None:
        src_id = str(src_id).strip().zfill(3)
        ids = {i for i in ids if i[2] == src_id}
    if not ids:
        raise SystemExit("ERROR: folder model senjata (weapon/<Tipe>/<Prefix>NNN) tidak ditemukan")
    if len({i[2] for i in ids}) > 1:
        raise SystemExit("ERROR: ditemukan lebih dari satu ID sumber (%s); isi ID sumber manual"
                         % ", ".join(sorted("%s%s" % (i[1], i[2]) for i in ids)))
    src_id = next(iter(ids))[2]
    if len({(i[0], i[1]) for i in ids}) > 1:
        raise SystemExit("ERROR: mod berisi lebih dari satu tipe senjata; tidak didukung")
    mapping, seen = {}, {}
    for r in rels:
        parts = _split(r)
        new = r
        low = [x.lower() for x in parts]
        if drop_prefab and 'prefab' in low[:4] and '.pfb.' in low[-1]:
            mapping[r] = None; continue
        if len(parts) >= 6 and low[2] == 'weapon' and _WEAPON_DIR.match(parts[4]) \
                and parts[4].endswith(src_id):
            parts[4] = parts[4][:-3] + dst_id
            parts[-1] = re.sub(r'(?<!\d)%s(?!\d)' % src_id, dst_id, parts[-1])
            new = '/'.join(parts)
        if new in seen:
            raise SystemExit("ERROR: tabrakan nama setelah penggantian ID: %s" % new)
        seen[new] = r; mapping[r] = new
    return mapping, src_id

def patch_mdf2_paths(data, src_id, dst_id):
    """Ganti ID di dalam path tekstur (string UTF-16 yang memuat 'weapon/') pada file .mdf2.
    Panjang string tetap sama (3 digit -> 3 digit), jadi offset file tidak bergeser.
    Nama material (mis. 'Lan_117') sengaja tidak diubah karena hash namanya tersimpan di file."""
    pat = re.compile(r'(?<!\d)%s(?!\d)' % re.escape(src_id))
    def fix(m):
        txt = m.group().decode('utf-16le')
        if 'weapon/' not in txt.lower():
            return m.group()
        return pat.sub(dst_id, txt).encode('utf-16le')
    return re.sub(rb'(?:[\x20-\x7e]\x00){4,}', fix, data)

def detect_kind(path):
    """'dir' | 'zip' | 'rar' | None  (deteksi dari isi file, bukan ekstensi)."""
    if os.path.isdir(path): return 'dir'
    with open(path, 'rb') as f: head = f.read(8)
    if head[:4] in (b'PK\x03\x04', b'PK\x05\x06'): return 'zip'
    if head[:6] == b'Rar!\x1a\x07': return 'rar'
    return None

def _safe_extract_zip(path, dest):
    root = os.path.realpath(dest)
    with zipfile.ZipFile(path) as z:
        for m in z.infolist():
            target = os.path.realpath(os.path.join(dest, m.filename))
            if target != root and not target.startswith(root + os.sep):
                raise SystemExit("ERROR: path berbahaya di dalam arsip: %s" % m.filename)
        z.extractall(dest)

def _extract_rar(path, dest):
    with open(path, 'rb') as f: head = f.read(8)
    if head == b'Rar!\x1a\x07\x01\x00':            # RAR5 -> pengekstrak bawaan (murni Python)
        import rar5
        try:
            rar5.extract(path, dest)
        except rar5.RarError as e:
            raise SystemExit("ERROR: %s" % e)
        return
    # RAR4 (lama): hanya lewat 'rarfile' + unrar (mode CLI/PC)
    try:
        import rarfile
    except ImportError:
        raise SystemExit("ERROR: RAR versi lama (4) belum didukung; simpan ulang sebagai "
                         "RAR5 atau ZIP")
    with rarfile.RarFile(path) as r:
        root = os.path.realpath(dest)
        for n in r.namelist():
            target = os.path.realpath(os.path.join(dest, n))
            if target != root and not target.startswith(root + os.sep):
                raise SystemExit("ERROR: path berbahaya di dalam arsip: %s" % n)
        r.extractall(dest)

def port_mod(src, out_pak, log=print, dst_id=None, src_id=None):
    tmp = None
    kind = detect_kind(src)
    if kind in ('zip', 'rar'):
        tmp = tempfile.mkdtemp(prefix='mhr_')
        (_safe_extract_zip if kind == 'zip' else _extract_rar)(src, tmp)
        src = tmp
    elif kind is None:
        raise SystemExit("ERROR: input harus berupa .zip, .rar, atau folder")
    try:
        nat = find_natives(src)
        if not nat: raise SystemExit("ERROR: folder 'natives' tidak ditemukan")
        parent = os.path.dirname(nat)
        files = []
        for dp, _, fn in os.walk(nat):
            for f in fn:
                files.append(os.path.join(dp, f))
        files.sort(key=lambda p: p.lower())
        remap = None
        if dst_id:
            rels = [os.path.relpath(p, parent).replace(os.sep, '/') for p in files]
            remap, sid = plan_retarget(rels, dst_id, src_id)
            log("Ganti ID model: %s -> %s" % (sid, str(dst_id).zfill(3)))
        entries = []
        for i, p in enumerate(files, 1):
            rel = os.path.relpath(p, parent).replace(os.sep, '/')
            if remap is not None:
                if remap[rel] is None:
                    log("[%d/%d] dibuang  %s (prefab ID lama)" % (i, len(files), rel)); continue
                if remap[rel] != rel: log("          rename -> %s" % remap[rel].split('/')[-1])
                rel = remap[rel]
            parts = rel.split('/')
            if len(parts) > 1 and parts[1].upper() == 'STM': parts[1] = 'NSW'
            rel = '/'.join(parts)
            data = open(p, 'rb').read()
            if remap is not None and re.search(r'\.mdf2\.\d+$', rel.lower()):
                data = patch_mdf2_paths(data, sid, str(dst_id).strip().zfill(3))
            if rel.lower().endswith('.tex.28'):
                log("[%d/%d] tekstur  %s" % (i, len(files), rel))
                data = pc_tex_to_switch_tex(data)
            else:
                log("[%d/%d] salin    %s" % (i, len(files), rel))
            entries.append((rel, data))
        build_pak(entries, out_pak)
        log("SELESAI -> %s (%d file)" % (out_pak, len(entries)))
        return entries
    finally:
        if tmp: shutil.rmtree(tmp, ignore_errors=True)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    opt = dict(a[2:].split('=', 1) for a in sys.argv[1:] if a.startswith('--') and '=' in a)
    out = args[1] if len(args) > 1 else 're_chunk_000.pak.patch_00y.pak'
    # contoh: python mhr_port.py mod.zip out.pak --dst=105 [--src=624]
    port_mod(args[0], out, dst_id=opt.get('dst'), src_id=opt.get('src'))
