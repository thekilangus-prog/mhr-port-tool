import traceback
import mhr_port

def run(src, out, dst_id="", src_id="", drop_prefab=False):
    """dst_id kosong = tanpa penggantian ID (perilaku lama)."""
    lines = []
    try:
        mhr_port.port_mod(src, out, log=lines.append,
                          dst_id=(dst_id or None), src_id=(src_id or None),
                          drop_prefab=bool(drop_prefab))
        return "OK\n" + "\n".join(lines)
    except SystemExit as e:
        return "GAGAL\n" + "\n".join(lines) + "\n" + str(e)
    except Exception as e:
        tb = "".join(traceback.format_exc().splitlines(True)[-6:])
        return ("GAGAL\n" + "\n".join(lines[-15:]) + "\n"
                + type(e).__name__ + ": " + str(e) + "\n" + tb)
