import mhr_port

def run(src, out):
    lines = []
    try:
        mhr_port.port_mod(src, out, log=lines.append)
        return "OK\n" + "\n".join(lines)
    except SystemExit as e:
        return "GAGAL\n" + "\n".join(lines) + "\n" + str(e)
    except Exception as e:
        return "GAGAL\n" + "\n".join(lines) + "\n" + type(e).__name__ + ": " + str(e)
